# Ajouter une v2 aux services REST
Modifier le fichier `composer.json` :
```
{
    ...
    "autoload": {
       ...
        "psr-4": {
            "V1\\": "EventSphere/v1/",
            "V2\\": "EventSphere/v2/"
        }
    }
}
```

Lancer la commande `composer dump-autoload`, puis copier les fichier de `vendor/` sur le serveur FTP.

Créer un répertoire `v2` dans le dossier `EventSphere`.
Ajouter le fichier `index.php` et `.htaccess` en modifiant le contenu.

