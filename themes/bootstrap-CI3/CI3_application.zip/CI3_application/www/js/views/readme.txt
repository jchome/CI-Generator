this directory contains javascript files for the application.


