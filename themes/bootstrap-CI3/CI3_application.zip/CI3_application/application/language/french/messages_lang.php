<?php
/**
 * Global messages
 */

$lang['form.button.save'] = "Enregistrer";
$lang['form.button.cancel'] = "Annuler";
$lang['form.button.edit'] = "Editer";
$lang['form.button.delete'] = "Supprimer";
$lang['form.button.create'] = "Ajouter";
$lang['form.button.download'] = "Télécharger";
$lang['form.button.send'] = "Envoyer";

$lang['object.tableheader.actions'] = "Actions";


$lang['form.button.backToList'] = "Retour";

$lang['login'] = "Identifiant";
$lang['password'] = "Mot de passe";
$lang['connect'] = "Se connecter";


/* forgotPassword */
$lang['forgotPassword.message.title'] = "Mot de passe oublié";
$lang['forgotPassword.form.email'] = "Saisissez votre email";
$lang['forgotPassword.form.send'] = "Envoyer";

$lang['forgotPassword.form.notfound'] = "L'adresse email est inconnue.";
$lang['forgotPassword.form.mail_sent'] = "Un message a été envoyé à l'adresse email.";
$lang['forgotPassword.form.mail_error'] = "Erreur lors de l'envoi du message.";
$lang['forgotPassword.form.mail_multiple'] = "Plusieurs utilisateurs avec le même mail...";
$lang['forgotPassword.form.cancel'] = "Annuler";


/* signin */
$lang['signin.message.title'] = "Créer un compte";
$lang['signin.form.email'] = "Saisissez votre email";
$lang['signin.form.step2'] = "Etape 2";
$lang['signin.form.send'] = "Envoyer";

$lang['signin.form.mail_already_taken'] = "Cet email est déjà utilisé. Veuillez en choisir un autre.";
$lang['signin.form.login_already_taken'] = "Ce login de connexion est déjà utilisé. Veuillez en choisir un autre.";

$lang['signin.form.usrlblgn.label'] = "Login";
$lang['signin.form.usrlbpwd.label'] = "Mot de passe";
$lang['signin.form.usrlbnom.label'] = "Pseudo";
$lang['signin.form.usrlbmai.label'] = "Votre email";

$lang['signin.form.usrlblgn.description'] = "Choisissez votre login de connexion";
$lang['signin.form.usrlbpwd.description'] = "Choisissez votre mot de passe de connexion";
$lang['signin.form.usrlbnom.description'] = "Saisissez votre nom (qui apparaitra aux autres utilisateurs)";

$lang['signin.form.done'] = "La création de votre compte s'est terminée avec succès. Veuillez vous connecter.";
$lang['signin.form.error'] = "La création de votre compte s'a pu aboutir.";

$lang['signin.form.cancel'] = "Annuler";

?>
