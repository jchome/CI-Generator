<?php

$lang['ut_passed'] = "<span class=\"check\">&#10004</span>";
$lang['ut_failed'] = "<span class=\"cross\">&#10008</span>";
$lang['ut_test_name'] = "test ";
$lang['ut_result'] = "X";


?>