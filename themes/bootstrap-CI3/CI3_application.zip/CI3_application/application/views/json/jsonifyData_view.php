<?php
/*
 * Use this view with the $data variable (an object or an array)
 *
 */

$this->load->helper('jsonwrapper/jsonwrapper');
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
echo json_encode($data); ?>

