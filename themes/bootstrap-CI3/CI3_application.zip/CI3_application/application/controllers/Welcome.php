<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Welcome extends CI_Controller {
	
	function __construct(){
		parent::__construct();
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->database();
		$this->load->library('form_validation');
		
		$this->load->model('UserModel');
		$this->load->library('UserService');
	}
	
	public function index(){
		 
	    $formSend = $this->input->post('formSend');

		// on est déjà connecté et on repart sur l'accueil
		if($formSend == "" && $this->session->userdata('user_id') != null){
			$this->redirectPage($this->session->userdata('user_id'), $this->session->userdata('user_name'));
		}
		$this->form_validation->set_error_delimiters('<div class="col-md-offset-4 col-sm-offset-4 col-md-4 col-sm-4">'.
	       '<div class="panel panel-danger">'.
		   '<div class="panel-heading">Attention</div>'.
		   '<div class="panel-body">', '</div></div></div>');
		$this->form_validation->set_rules('login', 'lang:login', 'trim|required|encode_php_tags');
		$this->form_validation->set_rules('password', 'lang:password', 'trim|required|encode_php_tags');
		
		// Premier appel en GET, sans soumettre le formulaire
		if($formSend != "true") {
		    $this->load->view('welcome_message');
		    return;
		}
		
		// passage des valisations
		if($this->form_validation->run() == FALSE){
		    $this->load->view('welcome_message');
			return;
		}
		
		$data = Array();
		$login = $this->input->post('login'); 
		$password = $this->input->post('password');
	
		$criteria = Array( new Criteria('usrlblgn', Criteria::$EQ, $login),
				new Criteria('usrlbpwd', Criteria::$EQ, $password)
		);
		$allUsers = $this->userservice->getAllByCriteria($this->db, $criteria);
		if(sizeOf($allUsers) == 1){
			$user = end($allUsers);
			$this->session->set_userdata('user_name', $user->usrlbnom . " " . $user->usrlbprn);
			$this->session->set_userdata('user_id', $user->usridusr);
			log_message('debug','[welcome.php] : user connected: '. $user->usrlblgn);
			$this->redirectPage($user->usridusr);
		}else{
			$data['message'] = 'Identifiant ['.$login.'] ou mot de passe incorrect...';
			log_message('debug','[welcome.php] : user NOT connected');
			$this->load->view('welcome_message',$data);
		}
		
	}
	
	private function redirectPage($user_id){
	    redirect('user/listusers/index');
	}
	
	/**
	 * Deconnexion
	 */
	function logout(){
		$this->session->unset_userdata('user_name');
		$this->session->unset_userdata('user_id');
		redirect('welcome/index'); 
	}

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
