<?php
$this->load->helper('url');
$this->load->helper('form');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Welcome</title>
<link rel="stylesheet" href="<?=base_url()?>www/css/main.css" type="text/css" media="screen" title="default" />
<!-- Bootstrap -->
<link href="<?=base_url()?>www/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">

<link rel="stylesheet" href="<?=base_url()?>www/bootstrap/css/override.css">

<!-- http://fortawesome.github.com/Font-Awesome/#icons-new -->
<link href="<?=base_url()?>www/bootstrap/FortAwesome-Font-Awesome-13d5dd3/css/font-awesome.min.css"
	rel="stylesheet">

</head>
<body id="login-bg">
<div class="login-box">
	<div class="brand-login">
		<div class="brand-logo">MyApp</div>
	</div>

<!-- Start: login-holder -->
<div class="login-holder">
	<h2><i class="icon-signin"></i> Connexion</h2>
<?php 
if(isset($message) && $message != ""){
	?>
	<div class="login-error"><?= $message ?></div>
	<?php 
}

?>
	
<?php
$attributes_info = array('name' => 'LoginForm');
$fields_info = array("formSend" => "true");
echo form_open_multipart('welcome/index', $attributes_info, $fields_info );
?>
		<fieldset>
				
			<label for="username">Identifiant</label>
			<div class="div_text">
				<div class="input-prepend"><span class="add-on"><i class="icon-user"></i></span><input type="text" class="username span2" value="" id="login" name="login"></div>

			</div>
			
			<label for="password">Mot de passe</label>
			<div class="div_text">
				<div class="input-prepend"><span class="add-on"><i class="icon-lock"></i></span><input type="password" class="password span2" value="************" onfocus="this.value=''" class="login-inp" name="password" id="password"></div>

			</div>
				
			<div class="button_div"><input type="submit" class="btn btn-primary" value="Login" name="Submit"></div>

			<div class="clear"></div>
		</fieldset>

<?php
echo form_close('');
?>

</div>
<!-- End: login-holder -->

</div> 
<!-- End: login-box -->

</body>
</html>
