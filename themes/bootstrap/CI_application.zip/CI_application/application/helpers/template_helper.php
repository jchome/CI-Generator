<?php


if (!function_exists('htmlHeader')) {
	function htmlHeader($title){
		$htmlCode = metaTags() . titleTag($title) . siteCSS() . '

<script type="text/javascript">
function base_url(){return "'. base_url() .'";};
</script>
';
		return $htmlCode;
	}
}

if (!function_exists('bodyFooter')) {
	function bodyFooter(){
		$htmlCode = jquery();
		return $htmlCode;
	}
}

if (!function_exists('jquery')) {
	function jquery(){
		$htmlCode = '<script src="'.base_url().'www/bootstrap/js/jquery-1.9.1.js"></script>
	<script src="'.base_url().'www/bootstrap/js/bootstrap.min.js"></script>

	<script src="'.base_url().'www/bootstrap/bootstrap-datepicker-master/js/bootstrap-datepicker.js"></script>
	<script src="'.base_url().'www/bootstrap/colorpicker/js/bootstrap-colorpicker.js"></script>
	';
		return $htmlCode;
	}
}


if (!function_exists('metaTags')) {
	function metaTags(){
		$htmlCode = '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">';
		return $htmlCode;
	}
}

if (!function_exists('titleTag')) {
	function titleTag($title){
		$htmlCode = '<title>'. $title .'</title>';
		return $htmlCode;
	}
}


if (!function_exists('siteCSS')) {
	function siteCSS(){
		$htmlCode = '<!-- Bootstrap -->
<link href="'.base_url().'www/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">

<link rel="stylesheet" href="'.base_url().'www/bootstrap/css/override.css">

<link href="'.base_url().'www/bootstrap/bootstrap-datepicker-master/css/datepicker.css"
	rel="stylesheet">
<link href="'.base_url().'www/bootstrap/colorpicker/css/colorpicker.css" rel="stylesheet">

<!-- http://aristath.github.com/elusive-iconfont/#integration -->
<link rel="stylesheet"
	href="'.base_url().'www/bootstrap/elusive-iconfont-master/css/elusive-webfont.css">';
		return $htmlCode;
	}
}


if (!function_exists('customCSS')) {
	function customCSS(){
		$htmlCode = '<!-- Custom CSS -->
<link rel="stylesheet" href="'.base_url().'www/css/main.css" />';
		return $htmlCode;
	}
}



?>