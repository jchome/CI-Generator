<?php

if (!function_exists('formatInfo')) {
	function formatInfo($message){
		$htmlCode = '<div class="alert alert-success">
					<button class="close" data-dismiss="alert">&#10006;</button>
					<strong>OK</strong>
					<p>'.$message.'</p>
				</div>';
		return $htmlCode;
	}
}

if (!function_exists('formatWarn')) {
	function formatWarn($message){
		$htmlCode = '<div class="row-fluid">
			<div class="span6">
				<div class="alert alert-danger">
					<button class="close" data-dismiss="alert">&#10006;</button>
					<strong>Attention</strong>
					<p>'.$message.'</p>
				</div>
			</div>
		';
		return $htmlCode;
	}
}

if (!function_exists('formatError')) {
	function formatError($message){
		$htmlCode = '<div class="row-fluid">
			<div class="span6">
				<div class="alert alert-error">
					<button class="close" data-dismiss="alert">&#10006;</button>
					<strong>Erreur !</strong>
					<p>'.$message.'</p>
				</div>
			</div>
		';
		return $htmlCode;
	}
}

if (!function_exists('formatConfirm')) {
	function formatConfirm($message){
		$htmlCode = '<div class="alert alert-success">
					<button class="close" data-dismiss="alert">&#10006;</button>
					<strong>OK</strong>
					<p>'.$message.'</p>
				</div>';
		return $htmlCode;
	}
}



/**
 * $itemToShow --> $subItemToShow : 
 * Applications --> list || edit || detail
 * Objets --> list || edit
 */
if (!function_exists('htmlNavigation')) {
	function htmlNavigation($itemToShow, $subItemToShow, $parameter_1 = null, $parameter_2 = null){
		$session = $parameter_1;
		if($subItemToShow == 'fancy'){
			return "";
		}
		$htmlCode = '<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="navbar-inner">
			<div class="container">
				<a class="btn btn-navbar" data-toggle="collapse"
					data-target=".nav-collapse"> <span class="icon-bar"></span> <span
					class="icon-bar"></span> <span class="icon-bar"></span>
				</a> <a class="brand" title="Tableau de bord" href="'.base_url().'index.php/dashboard/indicateurs/index">
					<img src="'.base_url().'www/images/logo/logo-typo-S-gris.png"></a>
				<div class="nav-collapse collapse">
					<ul class="nav">
		';
		
		// pour les admin :
		if($session->userdata('user_id') == 0) {
			// cabinet
			$htmlCode .= '<li class="'.(($itemToShow == "cabinet")?('active'):('')).'"><a href="'.base_url().'index.php/cabinet/listcabinets">Cabinets</a>';
	
			// dieteticien
			$htmlCode .= '<li class="'.(($itemToShow == "dieteticien")?('active'):('')).'"><a href="'.base_url().'index.php/dieteticien/listdieteticiens">Diététicien</a>';
		
		}
		
		// pour les NON admin :
		if($session->userdata('user_id') != 0) {
			// patient
			$htmlCode .= '<li class="'.(($itemToShow == "patient")?('active'):('')).'"><a href="'.base_url().'index.php/patient/listpatients">Patients</a>';
			// medecin
			$htmlCode .= '<li class="'.(($itemToShow == "medecin")?('active'):('')).'"><a href="'.base_url().'index.php/medecin/listmedecins">Medecins</a>';
			
			// pour les Responsables :
			if($session->userdata('user_profile') == "RESP") {
				// Types de patient
				$htmlCode .= '<li class="'.(($itemToShow == "typepatient")?('active'):('')).'"><a href="'.base_url().'index.php/typepatient/listtypepatients">Types de patient</a>';
				
				// Types de consultation
				$htmlCode .= '<li class="'.(($itemToShow == "typeconsultation")?('active'):('')).'"><a href="'.base_url().'index.php/typeconsultation/listtypeconsultations">Types de consultation</a>';
			}
		
			$htmlCode .= '</ul>
					<form class="navbar-form navbar-left">
						<input type="text" placeholder="Rechercher un Patient" class="form-control col-lg-8 typehead-patient"
							data-provide="typeahead" autocomplete="off" data-items="10" style="width: 155px;"/>
						<input type="hidden" id="idPatient" name="idPatient" />
					</form>';
		}else{
			$htmlCode .= '</ul>';
		}
		// pour tous :
		$htmlCode .= '
					<ul class="nav navbar-nav navbar-right">
						<li class="dropdown user-info">
							<input type="hidden" name="session_user_id" id="session_user_id" value="'.$session->userdata('user_id').'"/>
							<a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-user"></i> '.$session->userdata('user_name').'<b class="caret"></b></a>
							<ul class="dropdown-menu">
								<li><a href="'.base_url().'index.php/welcome/logout">Logout</a></li>
							</ul>
						</li>
					</ul>
				</div> <!-- .navbar-collapse -->
			</div> <!-- .container -->
		</div> <!-- .navbar-inner -->
	</div> <!-- .navbar navbar-inverse navbar-fixed-top -->';
		
		
		return $htmlCode;
	}
}

?>