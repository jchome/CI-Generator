<?php

if (!function_exists('formatInfo')) {
	function formatInfo($message){
		$htmlCode = '<p>'.$message.'</p>';
		return $htmlCode;
	}
}

if (!function_exists('formatWarn')) {
	function formatWarn($message){
		$htmlCode = '<p>'.$message.'</p>';
		return $htmlCode;
	}
}

if (!function_exists('formatError')) {
	function formatError($message){
		$htmlCode = '<div class="row-fluid">
			<div class="span6">
				<div class="alert alert-error">
					<button class="close" data-dismiss="alert">&#10006;</button>
					<strong>Erreur !</strong>
					<p>'.$message.'</p>
				</div>
			</div>
		';
		return $htmlCode;
	}
}

if (!function_exists('formatConfirm')) {
	function formatConfirm($message){
		$htmlCode = '<div class="alert alert-success">
					<button class="close" data-dismiss="alert">&#10006;</button>
					<strong>OK</strong>
					<p>'.$message.'</p>
				</div>';
		return $htmlCode;
	}
}



/**
 * $itemToShow --> $subItemToShow : 
 * Applications --> list || edit || detail
 * Objets --> list || edit
 */
if (!function_exists('htmlNavigation')) {
	function htmlNavigation($itemToShow, $subItemToShow, $parameter_1 = null, $parameter_2 = null){
		$htmlCode = '<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="navbar-inner">
			<div class="container">
				<a class="btn btn-navbar" data-toggle="collapse"
					data-target=".nav-collapse"> <span class="icon-bar"></span> <span
					class="icon-bar"></span> <span class="icon-bar"></span>
				</a> <a class="brand" href="#">Project name</a>
				<div class="nav-collapse collapse">
					<ul class="nav">
						<li class="active"><a href="#">Home</a></li>
						<li><a href="#about">About</a></li>
						<li><a href="#contact">Contact</a></li>
					</ul>
				</div>
				<!--/.nav-collapse -->
			</div>
		</div>
	</div> <!-- .navbar -->
	';
		/*
		// Applications
		$htmlCode .= '<ul class="'.(($itemToShow == "Applications")?('current'):('select')).'"><li><a href="'.base_url().'index.php/listapplications"><b>Applications</b><!--[if IE 7]><!--></a><!--<![endif]-->
			<div class="select_sub '.(($itemToShow == "Applications")?('show'):('')).'">
				<ul class="sub">';
			// items
		$htmlCode .= '
					<li'.(($subItemToShow == "list")?(' class="sub_show"'):('')).'><a href="'.base_url().'index.php/listapplications">Liste</a></li>
					<li'.(($subItemToShow == "edit")?(' class="sub_show"'):('')).'><a href="'.(($subItemToShow == "list")?('#'):(base_url().'index.php/editapplication/index/'.$parameter_1)).'">Edition</a></li>
					<li'.(($subItemToShow == "detail")?(' class="sub_show"'):('')).'><a href="'.(($subItemToShow == "list")?('#'):(base_url().'index.php/detailapplication/index/'.$parameter_1)).'">Détail</a></li>';
		$htmlCode .= '
				</ul>
			</div>
			</li>
			</ul>';
				
		$htmlCode .= '<div class="nav-divider">&nbsp;</div>';
		
		// Objets
		$htmlCode .= '<ul class="'.(($itemToShow == "Objets")?('current'):('select')).'"><li><a href="'.base_url().'index.php/listobjets"><b>Objets</b><!--[if IE 7]><!--></a><!--<![endif]-->
			<div class="select_sub '.(($itemToShow == "Objets")?('show'):('')).'">
				<ul class="sub">';
			// items
		$htmlCode .= '
					<li'.(($subItemToShow == "list")?(' class="sub_show"'):('')).'><a href="'.base_url().'index.php/listobjets">Liste</a></li>
					<li'.(($subItemToShow == "edit")?(' class="sub_show"'):('')).'><a href="'.(($subItemToShow == "list")?('#'):(base_url().'index.php/edit')).'">Edition</a></li>';
		$htmlCode .= '
				</ul>
			</div>
			</li>
			</ul>';
				
		// Champs
		$htmlCode .= '<ul class="'.(($itemToShow == "Champs")?('current'):('select')).'"><li><a href="'.base_url().'index.php/listchamps"><b>Champs</b><!--[if IE 7]><!--></a><!--<![endif]-->
			<div class="select_sub '.(($itemToShow == "Champs")?('show'):('')).'">
				<ul class="sub">';
			// items
		$htmlCode .= '
					<li'.(($subItemToShow == "list")?(' class="sub_show"'):('')).'><a href="'.base_url().'index.php/listchamps">Liste</a></li>
					<li'.(($subItemToShow == "edit")?(' class="sub_show"'):('')).'><a href="'.(($subItemToShow == "list")?('#'):(base_url().'index.php/editchamp')).'">Edition</a></li>';
		$htmlCode .= '
				</ul>
			</div>
			</li>
			</ul>';
			*/
		/*
		// itemB
		$htmlCode .= '<ul class="'.(($itemToShow == "itemB")?('current'):('select')).'"><li><a href="'.base_url().'index.php/itemB"><b>itemB</b><!--[if IE 7]><!--></a><!--<![endif]-->
			<div class="select_sub '.(($itemToShow == "itemB")?('show'):('')).'">
				<ul class="sub">';
			// items
		$htmlCode .= '
					<li'.(($subItemToShow == "list")?(' class="sub_show"'):('')).'><a href="'.base_url().'index.php/list">list</a></li>
					<li'.(($subItemToShow == "edit")?(' class="sub_show"'):('')).'><a href="'.(($subItemToShow == "list")?('#'):(base_url().'index.php/edit')).'">Edition</a></li>';
		$htmlCode .= '
				</ul>
			</div>
			</li>
			</ul>';*/
		
		// end of menu
				
		
		return $htmlCode;
	}
}

/*
if (!function_exists('htmlMenu')) {
	function htmlMenu($userProfile){
		$htmlCode = '<ul id="nav" class="dropdown dropdown-horizontal">
		<li><a href="'.base_url().'index.php">Home</a></li>
		<li><a href="#" class="dir">Produits</a>
			<ul>
				<li><a href="'.base_url().'index.php/listproduits">Liste</a></li>
				<li><a href="'.base_url().'index.php/listproduits#new">Nouveau</a></li>
			</ul>
		</li>
		<li><a href="./" class="dir">Classement</a>
			<ul>
				<li class="empty">&#8250;&#8250; Catégories</li>
				<li><a href="'.base_url().'index.php/listcategories">Liste</a></li>
				<li><a href="'.base_url().'index.php/listcategories#new">Nouveau</a></li>
				<li class="empty">&#8250;&#8250; Sous-Catégories</li>
				<li><a href="'.base_url().'index.php/listsouscategories">Liste</a></li>
				<li><a href="'.base_url().'index.php/listsouscategories#new">Nouveau</a></li>
				<li class="empty">&#8250;&#8250; Rubriques</li>
				<li><a href="'.base_url().'index.php/listrubriques">Liste</a></li>
				<li><a href="'.base_url().'index.php/listrubriques#new">Nouveau</a></li>
			</ul>
		</li>
		<li><a href="./" class="dir">News</a>
			<ul>
				<li><a href="'.base_url().'index.php/listnewss">Liste</a></li>
				<li><a href="'.base_url().'index.php/listnewss#new">Nouvelle news</a></li>
			</ul>
		</li>
		<li><a href="./" class="dir">Quitter</a>
			<ul>
				<li><a href="'.base_url().'index.php/welcome/logout">Retour au site</a></li>
			</ul>
		</li>
		</ul>';
		return $htmlCode;
	}
}
*/
?>