<?php
/**
 * Global messages
 */

$lang['form.button.save'] = "Enregistrer";
$lang['form.button.cancel'] = "Annuler";
$lang['form.button.edit'] = "Editer";
$lang['form.button.delete'] = "Supprimer";
$lang['form.button.create'] = "Ajouter";
$lang['form.button.download'] = "Télécharger";

$lang['object.tableheader.actions'] = "Actions";


$lang['form.button.backToList'] = "Retour";

$lang['login'] = "Identifiant";
$lang['password'] = "Mot de passe";
$lang['connect'] = "Se connecter";

?>
