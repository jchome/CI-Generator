<?php
/**
 * Global messages
 */

$lang['form.button.save'] = "Enregistrer";
$lang['form.button.cancel'] = "Annuler";
$lang['form.button.edit'] = "Editer";
$lang['form.button.delete'] = "Supprimer";
$lang['form.button.create'] = "Ajouter";

$lang['object.tableheader.actions'] = "Actions";
?>
