/**
 * Script MySQL pour User
 * 
**/

CREATE TABLE `sysusr` (
	`usridusr` int NOT NULL AUTO_INCREMENT COMMENT 'Identifiant', 
	`usrlbnom` varchar(255) NOT NULL COMMENT 'Nom', 
	`usrlbprn` varchar(255) COMMENT 'Prénom', 
	`usrlblgn` varchar(32) NOT NULL COMMENT 'Login', 
	`usrlbpwd` varchar(32) NOT NULL COMMENT 'Password', 
	`usrlbmai` varchar(255) NOT NULL COMMENT 'Email' ,
	PRIMARY KEY (usridusr) 
);

INSERT INTO `dummy`.`sysusr` (`usridusr`, `usrlbnom`, `usrlbprn`, `usrlblgn`, `usrlbpwd`, `usrlbmai`) 
VALUES ('0', 'Administrateur', null, 'admin', 'admin', 'dummy-admin@yopmail.com');



