<?php
/*
 * Created by generator
 *
 */

/***************************************************************************
 * DO NOT MODIFY THIS FILE, IT IS GENERATED
 ***************************************************************************/

class User_model extends CI_Model {
	
	/**
	* Identifiant systeme
	* @var int
	*/
	var $usridusr;

	/**
	* Nom de l'utilisateur
	* @var varchar(255)
	*/
	var $usrlbnom;

	/**
	* Prénom de l'utilisateur
	* @var varchar(255)
	*/
	var $usrlbprn;

	/**
	* Identifiant de connexion à l'application
	* @var varchar(32)
	*/
	var $usrlblgn;

	/**
	* Mot de passe de connexion à l'application
	* @var password(32)
	*/
	var $usrlbpwd;

	/**
	* Adresse email de contact
	* @var varchar(255)
	*/
	var $usrlbmai;


	
	
	/**
	 * Constructeur
	 */
	function __construct(){
		parent::__construct();
		$this->load->helper('utils');
		$this->load->helper('criteria');
	}
	
	
	/***************************************************************************
	 * DO NOT MODIFY THIS FILE, IT IS GENERATED
	 ***************************************************************************/

}

?>
