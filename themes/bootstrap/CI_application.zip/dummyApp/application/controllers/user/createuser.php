<?php
/*
 * Created by generator
 * 
 */

class CreateUser extends CI_Controller {
	
	/**
	 * Constructeur
	 */
	function __construct(){
		parent::__construct();
		$this->load->model('User_model');
		$this->load->library('UserService');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->library('form_validation');
		$this->load->database();

		
	}
	
	/**
	 * page de creation d'un user
	 */	
	public function index(){
		$data = Array();
		// Recuperation des objets references

		$this->load->view('user/createuser_view', $data);
	}
	
	/**
	 * Ajout d'un User
	 */
	public function add(){
	
		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');

		$this->form_validation->set_rules('usridusr', 'lang:user.form.usridusr.label', 'trim|required');
		$this->form_validation->set_rules('usrlbnom', 'lang:user.form.usrlbnom.label', 'trim|required');
		$this->form_validation->set_rules('usrlbprn', 'lang:user.form.usrlbprn.label', 'trim');
		$this->form_validation->set_rules('usrlblgn', 'lang:user.form.usrlblgn.label', 'trim|required');
		$this->form_validation->set_rules('usrlbpwd', 'lang:user.form.usrlbpwd.label', 'trim|required');
		$this->form_validation->set_rules('usrlbmai', 'lang:user.form.usrlbmai.label', 'trim|required');
		
		if($this->form_validation->run() == FALSE){
			$this->load->view('user/createuser_view');
		}
		
		// Insertion en base
		$model = new User_model();
		$model->usridusr = $this->input->post('usridusr');
		$model->usrlbnom = $this->input->post('usrlbnom');
		$model->usrlbprn = $this->input->post('usrlbprn');
		$model->usrlblgn = $this->input->post('usrlblgn');
		$model->usrlbpwd = $this->input->post('usrlbpwd');
		$model->usrlbmai = $this->input->post('usrlbmai');
		$this->userservice->insertNew($this->db, $model);
		

	
		$this->session->set_flashdata('msg_info', $this->lang->line('user.message.confirm.added'));
	
		// Recharge la page avec les nouvelles infos
		redirect('user/listusers/index');
	}
}
?>