<?php
/*
 * Created by generator
 * 
 */

class CreateUserJson extends CI_Controller {
	
	/**
	 * Constructeur
	 */
	function __construct(){
		parent::__construct();
		$this->load->model('User_model');
		$this->load->library('UserService');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->database();

		
	}
	
	/**
	 * page de creation d'un user
	 */	
	public function index(){
		$data = Array();
		// Recuperation des objets references

		$this->load->view('user/createuser_fancyview', $data);
	}
	
	/**
	 * Ajout d'un User
	 */
	public function add(){
	
		// Insertion en base
		$model = new User_model();
		$model->usridusr = $this->input->post('usridusr'); 
		$model->usrlbnom = $this->input->post('usrlbnom'); 
		$model->usrlbprn = $this->input->post('usrlbprn'); 
		$model->usrlblgn = $this->input->post('usrlblgn'); 
		$model->usrlbpwd = $this->input->post('usrlbpwd'); 
		$model->usrlbmai = $this->input->post('usrlbmai'); 
		$this->userservice->insertNew($this->db, $model);

	
		$this->session->set_flashdata('msg_info', $this->lang->line('user.message.confirm.added'));
	
		// renvoie vers la jsonification du modèle
		$data['user'] = $model;
		$this->load->view('user/jsonifyUnique_view', $data);
	}
}
?>
