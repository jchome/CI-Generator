<?php
/**
 * Global messages
 */

$lang['form.button.save'] = "Enregistrer";
$lang['form.button.cancel'] = "Annuler";
$lang['form.button.edit'] = "Editer";
$lang['form.button.delete'] = "Supprimer";
$lang['form.button.create'] = "Ajouter";
$lang['form.button.download'] = "Télécharger";

$lang['object.tableheader.actions'] = "Actions";


$lang['form.button.backToList'] = "Retour";

$lang['login'] = "Identifiant";
$lang['password'] = "Mot de passe";
$lang['connect'] = "Se connecter";


/* forgotPassword */
$lang['forgotPassword.message.title'] = "Mot de passe oublié";
$lang['forgotPassword.form.email'] = "Saisissez votre email";
$lang['forgotPassword.form.send'] = "Envoyer";

$lang['forgotPassword.form.notfound'] = "L'adresse email est inconnue.";
$lang['forgotPassword.form.mail_sent'] = "Un message a été envoyé à l'adresse email.";
$lang['forgotPassword.form.mail_error'] = "Erreur lors de l'envoi du message.";
$lang['forgotPassword.form.mail_multiple'] = "Plusieurs utilisateurs avec le même mail...";
$lang['forgotPassword.form.cancel'] = "Annuler";

?>
