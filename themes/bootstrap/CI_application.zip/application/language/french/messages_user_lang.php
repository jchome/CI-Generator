<?php
/**
 * Message file for entity User
 * 
 * Please don't forget to load this file:
 *  Solution A : Use "/application/config/autoload.php"
 *               Add this line:
 *               $autoload['language'] = array(..., 'messages_user', ...);
 *
 *  Solution B : Load this message file anywhere you want.
 *  
 */
$lang['user.message.askConfirm.deletion'] = "Désirez-vous supprimer ce User ?";

$lang['user.message.confirm.deleted'] = "User supprimé";
$lang['user.message.confirm.added'] = "User créé avec succès";
$lang['user.message.confirm.modified'] = "User mis à jour avec succès";

$lang['user.form.create.title'] = "Ajouter un user";
$lang['user.form.edit.title'] = "Editer un user";
$lang['user.form.list.title'] = "Liste des users";

$lang['user.menu.item'] = "User";


$lang['user.form.usridusr.label'] = "Identifiant";
$lang['user.form.usridusr.description'] = "Identifiant systeme";
$lang['user.form.usrlbnom.label'] = "Nom";
$lang['user.form.usrlbnom.description'] = "Nom de l'utilisateur";
$lang['user.form.usrlbprn.label'] = "Prénom";
$lang['user.form.usrlbprn.description'] = "Prénom de l'utilisateur";
$lang['user.form.usrlblgn.label'] = "Login";
$lang['user.form.usrlblgn.description'] = "Identifiant de connexion à l'application";
$lang['user.form.usrlbpwd.label'] = "Password";
$lang['user.form.usrlbpwd.description'] = "Mot de passe de connexion à l'application";
$lang['user.form.usrlbmai.label'] = "Email";
$lang['user.form.usrlbmai.description'] = "Adresse email de contact";
$lang['user.form.usrfipho.label'] = "Photo";
$lang['user.form.usrfipho.description'] = "Photo ou avatar de l'utilisateur";


?>