/**
 * Script MySQL pour User
 * 
**/

CREATE TABLE `sysusr` (
	`usridusr` int NOT NULL AUTO_INCREMENT COMMENT 'Identifiant', 
	`usrlbnom` varchar(255) NOT NULL COMMENT 'Nom', 
	`usrlbprn` varchar(255) COMMENT 'Prénom', 
	`usrlblgn` varchar(32) NOT NULL COMMENT 'Login', 
	`usrlbpwd` varchar(32) NOT NULL COMMENT 'Password', 
	`usrlbmai` varchar(255) NOT NULL COMMENT 'Email', 
	`usrfipho` varchar(4000) COMMENT 'Photo' ,
	PRIMARY KEY (usridusr) 
);




