/* Javascript for createuser_view.php */








//$("#usridusr").get(0).setCustomValidity('Champ requis');
//$("#usrlbnom").get(0).setCustomValidity('Champ requis');
//$("#usrlblgn").get(0).setCustomValidity('Champ requis');
//$("#usrlbpwd").get(0).setCustomValidity('Champ requis');
//$("#usrlbmai").get(0).setCustomValidity('Champ requis');


