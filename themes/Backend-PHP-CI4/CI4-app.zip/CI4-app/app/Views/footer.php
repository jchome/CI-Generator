

            </div>
        </div>
    </div>

    <!-- Main -->
    <script src="<?= base_url() ?>/assets/js/plugins/img-zoom.js"></script>
    <script src="<?= base_url() ?>/assets/js/main-back.js"></script>
    
</body>
</html>