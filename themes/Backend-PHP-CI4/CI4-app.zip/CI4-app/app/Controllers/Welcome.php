<?php 

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;

class Welcome extends BaseController {
	
	use ResponseTrait;

	private $userModel;

	public function index(){
		log_message('debug','[Welcome.php] : started...');
		helper(['form', 'security']);
		$formSend = $this->request->getPost('formSend');

		$session = session();

		// on est déjà connecté et on repart sur l'accueil
		if($formSend == ""){
			// The form is not sent
		 	if( $session->get('user_id') != null){
				 if($session->get('user_id') == 1){
					return redirect()->to('Generated/User/listusers/index');
				}else{
					return redirect()->to('App/Home/welcome');
				}
			 }else{
				return $this->view('welcome');
			 }
		}
		log_message('debug','[Welcome.php] : formSend OK.');

		if (! $this->validate([
			'login' => 'required',
			'password' => 'required',
		])) {
			log_message('debug','[welcome.php] : no parameter.');
			return $this->view('welcome');
		}
		log_message('debug','[Welcome.php] : login and password filled.');
		
		$login = $this->request->getPost('login'); 
		$password = $this->request->getPost('password');
		$data = Array();
	
		$this->userModel = new \App\Models\UserModel();
		$allUsers = $this->userModel->asObject()->where('login', $login)
			->findAll();
		log_message('debug','[Welcome.php] : Users found; '. sizeOf($allUsers) .'.');
		if(sizeOf($allUsers) != 1){
			$data['message'] = 'Identifiant ['.$login.'] ou mot de passe incorrect...';
			log_message('debug','[Welcome.php] : too much users with this login');
			$session->setFlashdata('error', 'Identifiant ['.$login.'] ou mot de passe incorrect...');
			return $this->view('welcome', $data);
		}
		$user = end($allUsers);
		// Check password
		if($password != $user->password && ! verify($password, $user->password)){
			$data['message'] = 'Identifiant ['.$login.'] ou mot de passe incorrect...';
			log_message('debug','[Welcome.php] : incorrect login or password');
			$session->setFlashdata('error', 'Identifiant ['.$login.'] ou mot de passe incorrect...');
			return $this->view('welcome', $data);
		}

		if($user->profile != 'ADMIN'){
			$data['message'] = 'Utilisateur ['.$login.'] n est pas ADMIN...';
			log_message('debug','[Welcome.php] : user is not ADMIN');
			$session->setFlashdata('error', 'Utilisateur ['.$login.'] n est pas ADMIN...');
			return $this->view('welcome', $data);
		}
		$session->set('user_id', $user->id);
		$session->set('currentUser', $user);
		log_message('debug','[Welcome.php] : user connected: '. $login);
		log_message('debug','[Welcome.php] session/userid = ' . $session->get('user_id'));

		// Add the token for the user
		$user->token = null; // Empty token = no external connection allowed 
		$user->expiration_token = null; // Empty expiration date = no external connection allowed 
		$this->userModel->update($user->id, $user);

		//$session->setFlashdata('token', $user['token']);
		return redirect()->to('Generated/User/listusers/index');
		
	}

	/**
	 * Return a json message
	 */
	public function resetPassword(){

		helper(['form']);
		$formSend = $this->request->getPost('formSend');
		if($formSend == ""){
			return $this->respond([
				'text' => 'No parameter',
				'type' => 'error'
			], 500);
		}

		$email = $this->request->getPost('email'); 
		$rules = [
			"email" => "required|valid_email",
		];
		if (!$this->validate($rules)) {
			return $this->respond([
				'text' => 'invalid email',
				'type' => 'error'
			], 500);
		}

		// Find the user
		$this->userModel = new \App\Models\UserModel();
		$allUsers = $this->userModel->where('email', $email)->findAll();

		if(sizeOf($allUsers) != 1){
			return $this->respond([
				'text' => 'email not found(' . sizeOf($allUsers) . ')',
				'type' => 'error'
			], 404);
		}

		$user = end($allUsers);
		$this->sendPassword($user['email'], $user['login'], $user['password']);

		return $this->respond([
			'text' => 'ok',
			'email' => $email
		]);
	}

	public function view($page, $data = [])
	{
		if (! is_file(APPPATH . 'Views/' . $page . '.php')) {
			// Whoops, we don't have a page for that!
			throw new \CodeIgniter\Exceptions\PageNotFoundException($page);
		}

		$data['title'] = "Welcome";
		echo view($page, $data);
	}
	
	
	/**
	 * Deconnexion
	 */
	function logout(){
		$session = session();
		if($session->get('user_id') != null){
			// Reset the token
			$userModel = new \App\Models\UserModel();
			$user = $userModel->asObject()->find($session->get('user_id'));
			if($user){
				$user->token = null;
				$user->expiration_token = null;
				$userModel->update($user->id, $user);
			}
			$session->remove('user_id');
			$session->remove('currentUser');
		}

		return redirect()->to('welcome/index'); 
	}


}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
