# YouDance2

Application for tests : http://jc-apps.fr/YouDance/index.php/welcome/index



# Developper
## Access
### Espace client 
Accès : https://panel.lws.fr
Identifiant : LWS-684869
Mot de passe : t5J72Z9xe8

### Serveur Mysql
Hostname : 185.98.131.148
Nom de la base Mysql : jcapp2399566
Identifiant / login : jcapp2399566
Mot de passe : gf0vxcbpj9

https://mysql19.lwspanel.com/phpmyadmin


### Comptes email
nom = youdance
mot de passe = pU6_B6c_u8gauDd

nom = revizz
mot de passe = aE4!k2TbxA5yMnC


## Log SQL queries
vendor/codeigniter4/framework/system/Database/MySQLi/Connection.php - line 290

```
        try {
            // ----> //log_message('debug', $sql);
            return $this->connID->query($this->prepQuery($sql), $this->resultMode);
        } catch (mysqli_sql_exception $e) {
            log_message('error', $e->getMessage());

            if ($this->DBDebug) {
                throw $e;
            }
        }
```

## API on json URLs
### Get the user with a token
GET - /App/User/token/[TOKEN]
```
status: "ok" | "ko",
data: [
    {
        id: Number,
        name: String,
        firstname: String,
        login: String,
        email: String,
        password: String,
        profile: String,
        token: String,
        counter_xp: Number,
        counter_gems: Number,
        photo: String,
        language: {
            id: Number,
            name: String,
            code: String,
            flag: String,
        },
        preferences: Json String,
        expiration_token: Date
    }
]
```

### Get subscriptions for a user
GET - App/Subscription/getSubscriptionsForUser/[TOKEN]

Response:
```
status: "ok" | "ko",
data: [
    {
        id: Number,
        startDate: Date("YYYY-MM-DD"),
        endDate: Date("YYYY-MM-DD"),
        title: String,
        code: String,
        nb_content: Number,
    }
]
```

### Change the category for a user
POST - App/Profile/changeCategory
Request:
```
category-id: Number,
token: String
```

Response:
```
status: "ok" | "ko",
data: String
```

### Logout a user
GET - /App/Security/logout[TOKEN]

Response:
```
status: "ok" | "ko",
data: String
```

### Check server's connection
GET - /App/Security/csrf

Response:
```
status: "ok" | "ko",
data: {
    name: String,
    hash: String
}
```

### Sign in
POST - /App/Security/sign_in

Request:
```
login: String,
password: String,
formSend: Boolean
```

Response:
```
status: "ok" | "ko",
data: {
    token: String,
    lang: String ("fr")
}
```

### List of all languages
GET - /Generated/Language/Listlanguagesjson/

Response:
```
status: "ok" | "ko",
data: {
    orderBy:: String,
    asc: String ("asc),
    languages: [
        {
            id: Number,
            name: String,
            code: String,
            flag: String,
        }
    ],
    pager: Object

}
```

### List of categories for a user
GET - /App/Category/getForUser/[TOKEN]

Response:
```
status: "ok" | "ko",
data: {
    [
        id: Number,
        title: String,
        code: String,
        preview: String,
        archived: String
    ]
}
```

### Get the root parcours for a user
GET - /App/Parcours/getParcours/[TOKEN]

Response:
```
status: "ok" | "ko",
data: {
    [
        id: Number,
        title: String,
        category_id: Number,
        preview: String,
        description: String,
        access_id: Number,
        startDate: Date("YYYY-MM-DD"),
        endDate: Date("YYYY-MM-DD") | null,
        creationDate: Date("YYYY-MM-DD"),
        interactive: ?
        full_access: ?
    ]
}
```

### Get the full content data
GET - /App/Parcours/getFullContent/[TOKEN]/[CONTENT-ID]

Response:
```
status: "ok" | "ko",
data: {
    id: Number,
    title: String,
    category_id: Number,
    preview: String,
    description: String,
    access_id: Number,
    startDate: Date("YYYY-MM-DD"),
    endDate: Date("YYYY-MM-DD") | null,
    creationDate: Date("YYYY-MM-DD"),
    interactive: ?,
    full_access: ?,
    success: {
        id: Number,
        user_id: Number,
        content_id: Number,
        quotation: ?,
        dateRealization: Date("YYYY-MM-DD"),
        xp: ?,
        gems: ?,
        evaluation_answer_id: ?, 
    },
    children: [
        id: Number,
        title: String,
        category_id: Number,
        preview: String,
        description: String,
        access_id: Number,
        startDate: Date("YYYY-MM-DD"),
        endDate: Date("YYYY-MM-DD") | null,
        creationDate: Date("YYYY-MM-DD"),
        interactive: ?,
        full_access: ?,
        position: Number,
        success: {
            id: Number,
            user_id: Number,
            content_id: Number,
            quotation: ?,
            dateRealization: Date("YYYY-MM-DD"),
            xp: ?,
            gems: ?,
            evaluation_answer_id: ?, 
        },
    ]
}
```

### Get list of medias for a content
GET - /App/Parcours/getMedia/[TOKEN]/[CONTENT-ID]

Response:
```
status: "ok" | "ko",
data: {
    [
        id: Number,
        title: String,
        content_id: Number,
        description: String,
        preview: String,
        link: String,
        mime_type: String,
        order_num: Number,
        goal: String,
        redirection: String,
    ]
}
```

### Get list of properties for a content
GET - /App/Parcours/getProperties/[TOKEN]/[CONTENT-ID]

Response:
```
status: "ok" | "ko",
data: {
    [
        {
            parameter_id: Number,
            title: String,
            value: String,
            param_content_id: Number
        }
    ]
}
```

### Get tags for a content
GET - /App/Parcours/getTags/[TOKEN]/[CONTENT-ID]

Response:
```
status: "ok" | "ko",
data: [
    {
        id: Number,
        content_id: Number,
        tag_id: Number,
        label: String,
        category_id: Number
    }
]
```


### Get contents having a list of tags
GET - /App/Parcours/getContentsHavingTags/[TOKEN]/[LIST-OF-TAG-ID]

Response:
```
status: "ok" | "ko",
data: []
```


### Count number of children of a content
GET - /App/Parcours/getNumberOfChildContent/[TOKEN]/[CONTENT-ID]

Response:
```
status: "ok" | "ko",
data: Number
```


### Get messages for a user
GET - /App/Messages/getForUser/[TOKEN]

Response:
```
status: "ok" | "ko",
data: [
    {
        id: Number,
        title: String,
        start_date: Date,
        end_date: Date,
        target_user_id: Number,
        target_subscription_id: Number,
        target_category_id: Number,
        reading_date: Date,
    }
]
```

### Mark a message as read for a user
GET - /App/Messages/setRead/[TOKEN]/[MESSAGE_ID]

Response:
```
status: "ok" | "ko",
data: [
    {
        id: Number,
        user_id: Number,
        message_id: Number,
        reading_date: Date,
        deleted: String
    }
]
```

If the message is already read:
```
status: "ok" | "ko",
data: ""
```

### Get count of new messages for a user
GET - /App/Messages/countNewMessages/[TOKEN]

Response:
```
status: "ok" | "ko",
data: Number
```

### Delete a message by a user
POST - /App/Messages/delete/[TOKEN]
Request data: {
    message_id: Number
}

Response:
```
status: "ok" | "ko",
data: [
    {
        id: Number,
        user_id: Number,
        message_id: Number,
        reading_date: Date,
        deleted: String
    }
]
```

### List of favorites for a user
GET - /App/Favorite/getForUser/[TOKEN]/[CATEGORY_ID]

***A changer***

Response:
```
status: "ok" | "ko",
data: {
    [
        {
            content: ...
            medias: ...
            success_content: ...
            tags: ...
            properties: ...
            category: ...
        }
    ]
}
```

### Get "favorite" flag for a user
GET - /App/Favorite/getFavoriteFlag/[TOKEN]/[CONTENT_ID]

Response:
```
status: "ok" | "ko",
data: 
    is_favorite: Boolean
```

### Set a content as "favorite" for a user
POST - /App/Favorite/setFavoriteFlag/[TOKEN]
Request data: {
    content_id: Number,
    is_favorite: Boolean,
    path: String,
}

Response:
```
status: "ok" | "ko",
data: 
    is_favorite: Boolean
```



### todo
- get success
- set success

