import { defineConfig } from 'vite'
import { resolve } from 'path'
import image from '@rollup/plugin-image'
import { createHtmlPlugin } from 'vite-plugin-html'
import htmlPurge from 'vite-plugin-html-purgecss'

import app from './package.json';

export default defineConfig({
    //root: resolve(__dirname, 'app'),
    root: './app',
    base: './',
    resolve: {
      alias: {
        '~bootstrap': resolve(__dirname, 'node_modules/bootstrap'),
        '~bootstrap-icons': resolve(__dirname, 'node_modules/bootstrap-icons'),
      }
    },/*  //-- No build, because all CSS are not taken
    build: {
        outDir: '../dist',
        minify: false,
        emptyOutDir: true,
        cssCodeSplit: false,
        rollupOptions: {
          external: ['/assets.*\.js/'],
        },
    },*/
    plugins: [
        image(),
        htmlPurge(),
        createHtmlPlugin({
            //entry: resolve(__dirname, 'app/assets/index.js'), // for build
            entry: './assets/index.js', // for live run
            template: 'index.html',
            inject: {
              data: {
                title: 'index',
                injectScript: `<script>window.APP_VERSION = '${app.version}'</script><script src="./inject.js"></script>`,
              },
            }
        }),
    ],
    define: {
        'process.env.NODE_ENV': JSON.stringify('developpment'), //JSON.stringify('production'),
    },
});