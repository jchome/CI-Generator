import {LitElement, html} from 'lit'
import { translate, get } from 'lit-translate'
import { until } from 'lit/directives/until.js'
import { Toast, Modal } from 'bootstrap'
import { Preferences } from '@capacitor/preferences';

import LoginPage from './login.js'



export default class MainElement extends LitElement {
    static properties = { };

    static get styles() { };

    constructor() {
        super();
        this.user = undefined
        
        this.addEventListener('switchTheme', this.switchTheme )
        this.addEventListener('login', this.login )
        this.addEventListener('logout', this.logout )

        this.addEventListener('onMenu', this.onMenu )

    }
    
    /**
     * Don't use the shadow-root node. The "styles" property will not be used.
     * @returns 
     */
     createRenderRoot() {
        return this;
    }
    
    render() {
        return until(this.loadConf().then((conf)=> {
            if(this.user == undefined){
                return html`<app-login></app-login>`
            }
            return html`
                <app-navbar id="navbar"
                    icon-class="bi bi-key me-2"
                    .user=${this.user}
                    activeItem="Users">
                </app-navbar>
                <app-container id="container">
                    <app-panel id="panelMain">
						Welcome !
						<br>
						To add a list of items, like users, add this line in "main.js":
                        <pre><app-user-list .conf=${conf}></app-user-list></pre>
                        
                    </app-panel>
                </app-container>

                <!-- TOAST -->
                <div id="toast" class="toast toast-top" role="alert" aria-live="assertive" 
                    aria-atomic="true" data-bs-delay="5000">
                    <div class="toast-header">
                        <i class="bi bi-info-circle-fill me-2 icon-info"></i>
                        <i class="bi bi-check-circle-fill me-2 icon-success"></i>
                        <i class="bi bi-exclamation-triangle-fill me-2 icon-warning"></i>
                        <i class="bi bi-bug-fill me-2 icon-danger"></i>
                        <strong class="me-auto toast-title">Information</strong>
                        <small class="toast-subtitle">11 mins ago</small>
                        <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                    </div>
                    <div class="toast-body">
                        This is a toast message.
                    </div>
                </div>
            `
        }), 
        html`
            <div class="centered-loader">
                <div class="loader spinner-border" role="status">
                    <span class="visually-hidden">
                        ${ translate("app-main.loading") }
                    </span>
                </div>
            </div>
        `
        )
        
    }

    loadUser(){
        return new Promise((resolve) => {
            Preferences.get({ key: KEY_USER }).then((userPref) => {
                if(userPref != null && userPref.value != null){
                    return resolve(JSON.parse(userPref.value))
                }else{
                    return resolve()
                }
            })
        })
    }

    loadConf(){
        return new Promise((resolve, reject) => {
            this.loadUser().then( (userData) => {
                this.user = userData

                if(window.location.href.includes("?reload")){
                    this.loadConfForced().then(() => {
                        return resolve()
                    })
                }
                Preferences.get({ key: KEY_CONFIG }).then((confPref) => {
                    
                    // Comment the following test to reload the configuration
                    if(confPref != null && confPref.value != null){
                        // Conf is loaded
                        return resolve( JSON.parse(confPref.value) )
                    }else {
                        return this.loadConfForced()
                    }
    
                })
            })
            
        })
    }

    loadConfForced(){
        return new Promise((resolve, reject) => {
            fetch("/config.json")
            .then( (response) => response.json())
            .then( async (currentConf) => {
                Preferences.set({
                    key: KEY_CONFIG,
                    value: JSON.stringify(currentConf)
                }).then( () => { return resolve() })
            })
            .catch(error => {
                console.error('Error in configuration file: ', error)
                reject(error)
            });
        });
    }


    login(event){
        // Set the user token to prepare the 'call' request
        Preferences.set({
            key: KEY_USER_TOKEN,
            value: JSON.stringify(event.detail.token)
        }).then(() =>{

            call('/App/User/token/', 'GET').then((responseOk, responseFailure) => {
                if(responseOk && responseOk.status == "ok"){
                    if(responseOk.data && responseOk.data.profile && responseOk.data.profile != 'TEACHER'){
                        // Remove the user token
                        Preferences.remove({
                            key: KEY_USER_TOKEN,
                        });
                        alert("Vous n'avez pas le profil 'Professeur'.\nUtilisez un autre compte.")
                        return
                    }
                    Preferences.set({
                        key: KEY_USER,
                        value: JSON.stringify(responseOk.data)
                    }).then(() => {
                        this.user = responseOk.data
                        this.requestUpdate()
                    })

                }else{
                    console.error(responseOk, responseFailure)
                    alert("Error: " + responseFailure)
                }
            })
        })
    }


    logout(event){
        Preferences.set({
            key: KEY_USER,
            value: null
        }).then(() => {
            this.user = undefined
        })
        this.requestUpdate()
    }

    /**
     * When the user changed the theme
     * 
     * @param {Event} event 
     */
    switchTheme(event){
        const currentTheme = document.querySelector('html').getAttribute('data-bs-theme')
        if(currentTheme == 'light'){
            document.querySelector('html').setAttribute('data-bs-theme', "dark")
        }else{
            document.querySelector('html').setAttribute('data-bs-theme', "light")
        }
    }

    /**
     * Open the toast to display a message
     * 
     * @param {String} message 
     * @param {String} status can be 'info' | 'success' | 'warning' | 'danger'
     */
    toastMessage(message, status = 'info', title= "", subtitle = ""){
        const toastElt = (new Toast('#'+toast.id))
        toastElt.hide()
        toast.classList.remove('toast-danger', 'toast-info', 'toast-warning', 'toast-success')
        toast.classList.add('toast-'+status)
        toast.querySelector('.toast-title').innerHTML = title
        toast.querySelector('.toast-subtitle').innerHTML = subtitle
        toast.querySelector('.toast-body').innerHTML = message
        toastElt.show()
    }

    onMenu(event){
        if(event.detail.menu == undefined){
            alert("Error in onMenu")
            console.error("onMenu() event.detail=", event.detail)
            return 
        }
        const tagName = "app-"+event.detail.menu+"-list"
        this.querySelector('#panelMain').innerHTML = `<${tagName}></${tagName}>`
    }

    
}

customElements.define('app-main', MainElement);
