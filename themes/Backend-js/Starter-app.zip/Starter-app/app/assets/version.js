// Version file
window.APP_VERSION = "local"
// This file will be overwritten during the build
