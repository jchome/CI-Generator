# Détail du projet
Ce projet vise à créer une application back-end avec des paneaux, et des widgets.

## Installation
La commande `mpn i` devrait installer tous les modules requis...

## Lancement
Lancer `npm start` pour démarrer le serveur de développement.


# Build
Il se lance avec la commande `npm run build`.

## Utilisation de vite.js
Vide.js n'est utilisé que pour lancer l'application en mode developpement, sur le serveur local. Les modifications sont prises en compte rapidement et sans relancer de lignes de commande. Pour faire le build, webpack est utilisé.

## Utilisation de webpack
Webpack permet de créer la distribution (avec Electron), en compilant les fichier JS et CSS dans un seul fichier.
Les fichiers à packager sont dans `app/assets/index.js`. Ils seront fusionnés dans le fichier `dist/assets/index.js`.

## Script de build
Puisque le webpack ne fait que la fusion des fichiers JS et CSS dans `dist` , les autres fichiers doivent être copiés par le script `build.js`.

De plus, pour afficher la version de l'application (définie dans le fichier package.json), ce script crée le fichier `version.js`.
Ce fichier est importé par le `index.html` pour définir une variable et l'utiliser dans les composants.

## Build finalisé
Une fois le build terminé, le répertoire `<nom de l'application>-<version>` contient les fichiers nécessaire à l'éxecutable, dont l'archive des sources.

On peut lancer la commande `npm run start-electron` pour une execution en mode "développeur", avec le panneau de développeur et le menu d'Electron.
Il est aussi possible de lancer l'éxecutable `build/backoffice-*.exe` final, qui ne permet pas d'accéder au panneau de développeur, si le menu.

## Lister les fichiers de l'archive
```
node C:\Users\S0073882\.npm-global\node_modules\asar\bin\asar.js list .\build\resources\app.asar
```
