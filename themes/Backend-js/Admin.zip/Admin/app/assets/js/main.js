import {LitElement, html} from 'lit'
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { use, translate, get } from 'lit-translate'

import { until } from 'lit/directives/until.js'
import { Toast, Modal } from 'bootstrap'
import { Preferences } from '@capacitor/preferences';

import LoginPage from './login.js'

import * as generated from '../generated/index.js'


export default class MainElement extends LitElement {
    static properties = { 
        activeMenu: {type: String},
    };

    static get styles() { };

    constructor() {
        super();
        this.user = undefined
        this.conf = undefined
        this.activeMenu = undefined
        this.activeScreen = undefined
        
        this.addEventListener('switchTheme', this.switchTheme )
        this.addEventListener('login', this.login )
        this.addEventListener('logout', this.logout )

        this.addEventListener('onMenu', this.onMenu )

    }

    
    /**
     * Don't use the shadow-root node. The "styles" property will not be used.
     * @returns 
     */
     createRenderRoot() {
        return this;
    }
    
    render() {
        return until(use("fr").then(() => this.loadConf().then(()=> {
            if(this.user == undefined){
                return html`<app-login></app-login>`
            }
            if(this.activeMenu == undefined){
                this.activeScreen = 
                    html`<div class="centered-loader display-1">
                        ${ translate("app-main.welcome") }
                    </div>`
            }else{
                const template = `<app-${this.activeMenu}-list 
                    conf=${JSON.stringify(this.conf)} 
                    user="${JSON.stringify(this.user)}" 
                    visible="false">
                    </app-${this.activeMenu}-list>`
                this.activeScreen = html`${unsafeHTML(template)}`
            }
            return html`
                <app-navbar id="navbar"
                    icon-class="bi bi-key me-2"
                    .user=${this.user}>
                </app-navbar>
                <app-container>
                    <app-panel>
                    ${ this.activeScreen }
                    </app-panel>
                </app-container>

                <!-- TOAST -->
                <div id="toast" class="toast toast-top" role="alert" aria-live="assertive" 
                    aria-atomic="true" data-bs-delay="5000">
                    <div class="toast-header">
                        <i class="bi bi-info-circle-fill me-2 icon-info"></i>
                        <i class="bi bi-check-circle-fill me-2 icon-success"></i>
                        <i class="bi bi-exclamation-triangle-fill me-2 icon-warning"></i>
                        <i class="bi bi-bug-fill me-2 icon-danger"></i>
                        <strong class="me-auto toast-title">Information</strong>
                        <small class="toast-subtitle">11 mins ago</small>
                        <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                    </div>
                    <div class="toast-body">
                        This is a toast message.
                    </div>
                </div>
            `
        }), 
        html`
            <div class="centered-loader">
                <div class="loader spinner-border" role="status">
                    <span class="visually-hidden">
                        ${ translate("app-main.loading") }
                    </span>
                </div>
            </div>
        `
        ))
        
    }

    loadUser(){
        return new Promise((resolve) => {
            Preferences.get({ key: KEY_USER }).then((userPref) => {
                if(userPref != null && userPref.value != null){
                    const user = JSON.parse(userPref.value)
                    call('/api/v2/auth').then((responseOk) => {
                        if(responseOk && responseOk.status == "ok"){
                            return resolve(user)
                        }else{
                            return resolve()
                        }
                    })
                }else{
                    return resolve()
                }
            })
        })
    }

    loadConf(){
        return new Promise((resolve, reject) => {
            if(this.conf){
                return resolve()
            }

            this.loadUser().then( (userData) => {
                this.user = userData

                if(window.location.href.includes("?reload")){
                    this.loadConfForced().then(() => {
                        return resolve()
                    })
                }
                /*
                Preferences.get({ key: KEY_CONFIG }).then((confPref) => {
                    // Comment the following test to reload the configuration
                    if(confPref != null && confPref.value != null){
                        // Conf is loaded
                        this.conf = JSON.parse(confPref.value)
                        return resolve()
                    }else {
                        return this.loadConfForced().then( () => resolve() )
                    }
                })*/
                return this.loadConfForced().then( () => resolve() )
            })
        })
    }

    loadConfForced(){
        return new Promise((resolve, reject) => {
            fetch("./config.json")
            .then( (response) => response.json())
            .then( async (currentConf) => {
                this.conf = currentConf
                Preferences.set({
                    key: KEY_CONFIG,
                    value: JSON.stringify(currentConf)
                }).then( () => { return resolve() })
                //return resolve()
            })
            .catch(error => {
                console.error('Error in configuration file: ', error)
                reject(error)
            });
        });
    }


    login(event){
        // Set the user token to prepare the 'call' request
        Preferences.set({
            key: KEY_USER_TOKEN,
            value: JSON.stringify(event.detail.token)
        }).then(() =>{

            call('/Security/token/', 'GET').then((responseOk, responseFailure) => {
                if(responseOk && responseOk.status == "ok"){
                    if(responseOk.data && responseOk.data.profile && responseOk.data.profile != 'ADMIN'){
                        // Remove the user token
                        Preferences.remove({
                            key: KEY_USER_TOKEN,
                        });
                        alert("Vous n'avez pas le profil 'ADMIN'.\nUtilisez un autre compte.")
                        return
                    }
                    Preferences.set({
                        key: KEY_USER,
                        value: JSON.stringify(responseOk.data)
                    }).then(() => {
                        this.user = responseOk.data
                        this.requestUpdate()
                    })

                }else{
                    console.error(responseOk, responseFailure)
                    alert("Error: " + responseFailure)
                }
            })
        })
    }


    logout(event){
        Preferences.set({
            key: KEY_USER,
            value: null
        }).then(() => {
            this.user = undefined
        })
        this.requestUpdate()
    }

    /**
     * When the user changed the theme
     * 
     * @param {Event} event 
     */
    switchTheme(event){
        const currentTheme = document.querySelector('html').getAttribute('data-bs-theme')
        if(currentTheme == 'light'){
            document.querySelector('html').setAttribute('data-bs-theme', "dark")
        }else{
            document.querySelector('html').setAttribute('data-bs-theme', "light")
        }
    }

    /**
     * Open the toast to display a message
     * 
     * @param {String} message 
     * @param {String} status can be 'info' | 'success' | 'warning' | 'danger'
     */
    toastMessage(message, status = 'info', title= "", subtitle = ""){
        const toastElt = (new Toast('#'+toast.id))
        toastElt.hide()
        toast.classList.remove('toast-danger', 'toast-info', 'toast-warning', 'toast-success')
        toast.classList.add('toast-'+status)
        toast.querySelector('.toast-title').innerHTML = title
        toast.querySelector('.toast-subtitle').innerHTML = subtitle
        toast.querySelector('.toast-body').innerHTML = message
        toastElt.show()
    }

    onMenu(event){
        if(event.detail.menu == undefined){
            alert("Error in onMenu")
            console.error("onMenu() event.detail=", event.detail)
            return 
        }
        
        this.activeMenu = event.detail.menu
        
    }

}

customElements.define('app-main', MainElement);