import ____MyObject___ListElement from './____my_object___/list.js'
// ...


export { ____MyObject___ListElement, 
    // ...
 }