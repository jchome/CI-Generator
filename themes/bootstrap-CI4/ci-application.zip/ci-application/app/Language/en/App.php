<?php

return [
    "message" => [
        "type_your_id" => "Please type you id",
    ],
    "test" => "ok",
];
