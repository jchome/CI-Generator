

            </div>
        </div>
    </div>

    <!-- Main -->
    <script src="https://unpkg.com/trix@2.0.0/dist/trix.umd.min.js" type="text/javascript"></script>
    <script src="<?= base_url() ?>/assets/js/plugins/img-zoom.js" type="text/javascript"></script>
    <script src="<?= base_url() ?>/assets/js/main-back.js" type="text/javascript"></script>
    
</body>
</html>