<?php

return [
    "message" => [
        "type_your_id" => "Veuillez saisir votre identifiant",
        "welcome" => "Bienvenue",
    ],
    "form" => [
        "id" => "identifiant",
        "password" => "mot de passe",
        "connect" => "Se connecter",
        "forgotPassword" => "Mot de passe oublié",
        "signin" => "Créer un compte",
    ],
    "test" => "ok",
];
