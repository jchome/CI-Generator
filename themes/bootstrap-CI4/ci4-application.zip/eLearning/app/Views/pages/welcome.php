

<div class="container">
    <div class="row text-center">
        <div class="col-md-12">
            <h1><?= lang('App.message.welcome') ?></h1>
        </div>
    </div>

    <div class="row text-center ">
        <div class="col-md-12">

            <?= session()->getFlashdata('error') ?>
            <?= service('validation')->listErrors('errors_list') ?>
            <br />
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1">
        <div class="panel panel-default">
            <div class="panel-heading">
                <strong><?= lang('App.message.type_your_id') ?></strong>
            </div>
            <div class="panel-body">

                <form action="/welcome/index" method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="formSend" value="true"/>
                    <div class="form-group input-group">
                        <span class="input-group-addon"> <i class="glyphicon glyphicon-user"></i>
                        </span> <input type="text" class="form-control" placeholder="<?= lang('App.form.id') ?>" value="" id="login" name="login" />
                    </div>
                    <div class="form-group input-group">
                        <span class="input-group-addon"> <i class="glyphicon glyphicon-lock"></i>
                        </span> <input type="password" class="form-control" placeholder="mot de passe" name="<?= lang('App.form.password') ?>" id="password" />
                    </div>

                    <input type="submit" class="btn btn-primary btn-large" value="<?= lang('App.form.connect') ?>" name="Submit" />

                    <div class="clear"></div>
                    <div class="forgotpassword text-right">
                        <a href="/login/forgotpassword/index"><i class="glyphicon glyphicon-question-sign"></i> <?= lang('App.form.forgotPassword') ?> </a>
                    </div>
                    <div class="singin text-right">
                        <a href="/login/signin/index"><i class="glyphicon glyphicon-user"></i> <?= lang('App.form.signin') ?> </a>
                    </div>
                        
                </form>
            </div>
            <!-- .panel-body -->
        </div>
        <!-- .panel .panel-default -->
        <div class="row text-right">
            <em>&copy; 2022</em>
        </div>
    </div>
    <!-- .col-md-4 -->
</div>
<!-- .row -->
