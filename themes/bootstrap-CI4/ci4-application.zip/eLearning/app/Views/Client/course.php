
<!-- ======= Header ======= -->
<header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center justify-content-lg-between">

        <a class="order-lg-0 btn-back" href="<?= $back ?>">
            <i class="bi bi-chevron-left"></i>
        </a>
        <div class="header-title me-auto">
            <div class="main-title">
                <?= $course['title'] ?>
            </div>
            <div class="sub-title">
                <?php
                if($training['discipline'] == 0){
                    // No discipline
                    ?>
                    Parcours <?= $training['title'] ?>
                    <?php
                }else{
                    ?>
                    <?= $skillCollection[$training['discipline']]['title'] ?>
                    -
                    niveau <?=$training['level']?> 
                    <?php
                }
                ?>
            </div>
        </div>

    </div>
</header><!-- End Header -->

<!-- Detail of course -->
<section id="course">

    <!-- List of contents-->
    <div class="row ms-2 mb-2">
        <?php 
        for($i=1;$i<=5;$i++) { ?>
          <?php if($course['content'.$i] != "") { ?> 
            <button type="button" class="btn btn-primary thumb-content me-2" id="btn-content-<?= $i ?>" 
                onclick="showContent(<?= $i ?>)"> 
            #<?= $i ?>
            </button>
          <?php } 
        } ?>
    </div>

    <?php 
        for($i=1;$i<=5;$i++) { ?>
        <?php if($course['content'.$i] != "") {?>
    <div class="container" id="video-<?= $i ?>" style="display: none;">
        <video id="video-player" width="100%" height="100%" controls class="lazy"
            data-src="<?= $course['content'.$i] ?>"
            data-poster="<?= $course['content'.$i] ?>.jpg">>
            <source src="<?= $course['content'.$i] ?>" type="video/webm" 
                data-src="<?= $course['content'.$i] ?>">
            Votre navigateur ne supporte pas la lecture de la video.
        </video>
    </div>
        <?php } 
    }?>

</div>

</section>

<!-- jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

<script>
window.lazyLoadOptions = {
    elements_selector: ".lazy"
};

$('document').ready(function () {
    // Set the first content active
    for(var i=1;i<=5;i++){
        if( $("#btn-content-"+i) ){
            showContent(i);
            break;
        }
    }
});

function showContent(indexToShow){
    for(var i=1;i<=5;i++){
        if( $("#btn-content-"+i) && $("#btn-content-"+i).hasClass("active") ){
            // previous active index is "i";
            $("#btn-content-"+i).removeClass("active");
            $("#video-"+i).hide();
        }
    }
    $("#btn-content-"+indexToShow).addClass("active");
    $("#video-"+indexToShow).show();
}

/*
var video = document.querySelector('#video'),
    text = document.querySelector('#overlayText'),
    timer = document.querySelector('#timer');
 
setInterval(function() {
  if (video.currentTime > 2 && video.currentTime < 10) {
    text.style.display = 'block';
  }
  else {
    text.style.display = 'none';
  }
 
  timer.textCon
  */
</script>
<script async
  src="https://cdn.jsdelivr.net/npm/vanilla-lazyload@16.1.0/dist/lazyload.min.js">
</script>
