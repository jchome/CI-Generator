
<!-- ======= Header ======= -->
<header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center justify-content-lg-between">

        <a class="order-lg-0 btn-back" href="<?= $back ?>">
            <i class="bi bi-chevron-left"></i>
        </a>
        <span class="header-title me-auto">
        <?php
            if($training['discipline'] == 0){
                // No discipline
                ?>
                Parcours <?= $training['title'] ?>
                <?php
            }else{
                ?>
                <?= $skillCollection[$training['discipline']]['title'] ?>
                -
                niveau <?=$training['level']?> 
                <?php
            }
            ?>
        </span>

    </div>
</header><!-- End Header -->

<!-- List of courses of a training -->
<section id="training">

<?php
$counter = 1;
foreach($courseCollection as $course):
?>
        <a href="<?= base_url() ?>/index.php/Client/Course/index/<?= $course['id']?>/<?= $training['id'] ?>">
            <div class="d-inline-flex w-100 ms-1">
                <div class="justify-content-start align-self-center me-2">
                    <!-- counter -->
                    <span class="course-counter bg-primary"><?= $counter ?></span>
                </div>

                <!-- Detail of the course-->
                <div class="justify-content-end me-2 course">
                    <div class="title">
                        <?= $course['title'] ?><br/>
                    </div>
                    <div class="preview">
                       <img src="<?= base_url() ?>/uploads/<?= $course['preview'] ?>" class="img-fluid img-presentation rounded"><br/>
                        <!--img src="/uploads/course_1_preview.png" class="img-fluid img-presentation rounded"><br/-->
                    </div>
                    <div class="prof">
                        <span><?= $teacherCollection[$course['teacher']]['name'] ?></span>
                    </div>
                </div>
            </div>
        </a>
        
  <?php 
$counter++;
endforeach; 
?>

</section>