<!doctype html>
<html>

<head>
    <title>YouDance - Reset password</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />

    <!-- Bootstrap icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css" />

    <!-- Google font Montserrat width = 900 -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:900" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?= base_url() ?>/css/client.css">

</head>

<body>

<section>
        <div class="fullscreen">

            <div class="container">
                <div class="col-lg-6 offset-lg-3 col-md-8 offset-md-2 col-sm-12">
                    <h1 class="logo mb-4">
                        YouDance
                    </h1>
                    <?php if($result) { ?>
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Changement de mot de passe</h5>
                                <p class="card-text">
                                    email de connexion : <?= $user['email'] ?>
                                    <form action="<?= base_url() ?>/Client/Login" method="POST" class="row row-cols-lg-auto align-items-center">
                                        <input type="hidden" name="formSend" value="<?= $user['token'] ?>" />
                                        <input type="hidden" name="token" value="true" />
                                        <div class="col-12 mb-3">
                                            <label class="visually-hidden" for="inputPassword">Password</label>
                                            <div class="input-group">
                                                <div class="input-group-text">
                                                    <i class="bi bi-lock-fill"></i>
                                                </div>
                                                <input type="password" name="password" class="form-control" id="inputPassword" 
                                                    placeholder="password" onkeyup="checkPasswords()">
                                            </div>
                                        </div>
                                        <div class="col-12 mb-3">
                                            <label class="visually-hidden" for="inputPassword2">retapez le Password</label>
                                            <div class="input-group">
                                                <div class="input-group-text">
                                                    <i class="bi bi-lock-fill"></i>
                                                </div>
                                                <input type="password" name="password2" class="form-control" id="inputPassword2" 
                                                    placeholder="password" onkeyup="checkPasswords()">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <span id="error-password" style="color: red; display: none;">
                                                Les mots de passe ne correspondent pas.
                                            </span>
                                            <span id="complexity-password-weak" style="color: orange; display: none;">
                                                Le mot de passe a une complexité faible.
                                            </span>
                                            <span id="complexity-password-good" style="color: black; display: none;">
                                                Le mot de passe a une bonne complexité.
                                            </span>
                                            <span id="complexity-password-strong" style="color: green; display: none;">
                                                Le mot de passe a une complexité forte.
                                            </span>
                                            &nbsp;
                                        </div>
                                        <div class="col-12">
                                            <div class="d-grid gap-2 col-6 mx-auto">
                                                <button type="submit" class="btn-lg btn-primary" id="btnChangePasswd">Changer le mot de passe</button>
                                            </div>
                                        </div>
                                    </form>
                                </p>
                            </div>
                        </div>
                        
                    <?php }else{?>
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Erreur dans le token</h5>
                                <p class="card-text">
                                    Le token que vous avez reçu ne correspond pas à votre identifiant.
                                    <br>
                                    Veuillez recommancer la procédure du mot de passe oublié sur la page d'accueil.
                                </p>
                                <a href="<?= base_url() ?>/Client/Login" class="btn btn-primary">Page de login</a>
                            </div>
                        </div>
                    <?php } ?>
                    
                </div>
            </div>

        </div>
    </section>
    
<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" 
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

<!-- jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

<script>
function checkPasswords(){
    var passw1 = $("#inputPassword").val();
    var passw2 = $("#inputPassword2").val();
    // Check equality
    if(passw1 != passw2){
        $("#error-password").show();
        $("#complexity-password-weak").hide();
        $("#complexity-password-good").hide();
        $("#complexity-password-strong").hide();
        $("#btnChangePasswd").prop('disabled', true);
        return;
    }else{
        $("#btnChangePasswd").prop('disabled', false);
        $("#error-password").hide();
    }

    // Check complexity
    $("#complexity-password-weak").hide();
    $("#complexity-password-good").hide();
    $("#complexity-password-strong").hide();
    var strength = 0;
    if (passw1.length > 7) {
        strength += 1;
    }
    // Password contains both lower and uppercase characters
    if (passw1.match(/([a-z].*[A-Z])|([A-Z].*[a-z])/)){
        strength += 1;
    }
    // Password has numbers and characters
    if (passw1.match(/([a-zA-Z])/) && passw1.match(/([0-9])/)){
        strength += 1;
    }
    // Password has one special character
    if (passw1.match(/([!,%,&,@,#,$,^,*,?,_,~])/)){
        strength += 1;
    }  
    // Password has two special characters
    if (passw1.match(/(.*[!,%,&,@,#,$,^,*,?,_,~].*[!,%,&,@,#,$,^,*,?,_,~])/)){
        strength += 1;
    }
    if (strength < 2) {
        $("#complexity-password-weak").show();
        $("#complexity-password-good").hide();
        $("#complexity-password-strong").hide();
    } else if (strength == 2) {
        $("#complexity-password-weak").hide();
        $("#complexity-password-good").show();
        $("#complexity-password-strong").hide();
    } else {
        $("#complexity-password-weak").hide();
        $("#complexity-password-good").hide();
        $("#complexity-password-strong").show();
    }
}
</script>


</body>

</html>