<section id="home">
    <!-- List of trainings -->
<?php
foreach($trainings as $training):
?>
    <a href="<?= base_url() ?>/index.php/Client/Training/index/<?= $training['id'] ?>">
      <figure class="figure me-3 ms-3">
        <figcaption class="figure-caption header">
        <?=($training['discipline'] == 0)?(""):($skillCollection[$training['discipline']]['title'])?>
        -
        niveau <?=$training['level']?> 
        </figcaption>
        <?php
        if($training['picture']){ ?>
          <img src="<?= base_url() ?>/uploads/<?=$training['picture']?>" class="figure-img img-fluid rounded">
        <?php }else{ ?>
          <img src="<?= base_url() ?>/images/img_parcours_defaut.png" class="figure-img img-fluid rounded">
        <?php } ?>

        <!--figcaption class="figure-caption footer">
          x cours effectués
        </figcaption-->
      </figure>
    </a>
<?php 
endforeach; ?>


</section>
<script>
function disconnect(){
  if(confirm("Voulez-vous quitter l'application ?")){
    document.location.href = '<?= base_url("/Client/Home/logout") ?>';
  }
}
</script>