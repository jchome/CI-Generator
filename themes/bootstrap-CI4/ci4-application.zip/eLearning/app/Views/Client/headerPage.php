<!doctype html>
<html>

<head>
    <title><?= $title ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />

    <!-- Bootstrap icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css" />

    <!-- Google font Montserrat width = 900 -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:900" rel="stylesheet">
    
  <!-- Template Main CSS File -->
  <link href="<?= base_url() ?>/css/style.css" rel="stylesheet">
  <link href="<?= base_url() ?>/css/client.css" rel="stylesheet">

</head>

<body>

  