<!doctype html>
<html>

<head>
    <title>YouDance - Home</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />

    <!-- Bootstrap icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css" />

    <!-- Google font Montserrat width = 900 -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:900" rel="stylesheet">
    
  <!-- Template Main CSS File -->
  <link href="<?= base_url() ?>/css/style.css" rel="stylesheet">
  <link href="<?= base_url() ?>/css/client.css" rel="stylesheet">

</head>

<body>
    
  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center justify-content-lg-between">

    <nav id="navbar" class="navbar order-lg-0">
      <i class="bi bi-list mobile-nav-toggle"></i>
      <ul>
        <li><a class="nav-link scrollto" href="<?= base_url('/Client/Profile') ?>">Mon Compte</a></li>
        <li><a class="nav-link scrollto" href="mailto:julien.coron@gmail.com&subject=[YouDance] Bug">
          <i class="bi bi-envelope"></i> &nbsp;
          Signaler un bug
        </a></li>
        <li><a class="nav-link scrollto" href="mailto:alexandre.janer@gmail.com&subject=[YouDance] Contact">
          <i class="bi bi-envelope"></i> &nbsp;
          Contacter l'auteur
        </a></li>
        <li><a class="nav-link scrollto" href="javascript:disconnect()">Deconnexion</a></li>
      </ul>
    </nav><!-- .navbar -->

      <h1 class="logo me-auto" style="width: 100%;"><a href="index.html">You Dance</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto me-lg-0"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->


      <!--a href="#about" class="order-last user">
        <img src="<?= base_url() ?>/uploads/user_1_photo.jpg" class="user-photo">
      </a-->

    </div>
  </header><!-- End Header -->

  