
<!-- ======= Header ======= -->
<header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center justify-content-lg-between">

        <a class="order-lg-0 btn-back" href="<?= $back ?>">
            <i class="bi bi-chevron-left"></i>
        </a>
        <span class="header-title me-auto">
            Mon compte
        </span>

    </div>
</header><!-- End Header -->

<!-- My profile -->
<section id="profile">

<?php
$attributes_info = array('name' => 'EditForm', 'class' => 'form-horizontal');
$fields_info = array('id' => $user['id']);
echo form_open_multipart('Client/Profile/save', $attributes_info, $fields_info );
?>

    <div class="row mb-3"><!-- Nom : Nom de l'utilisateur -->
		<label for="name" class="col-sm-2 col-form-label"><?= lang('User.form.name.label') ?>
		</label>
		
		<div class="col-sm-10">
			<input class="form-control" type="text" name="name" id="name" value="<?= $user['name'] ?>" required  >
		</div>
	</div>


	<div class="row mb-3"><!-- Prénom : Prénom de l'utilisateur -->
		<label for="firstname" class="col-sm-2 col-form-label"><?= lang('User.form.firstname.label') ?>
		</label>
		
		<div class="col-sm-10">
			<input class="form-control" type="text" name="firstname" id="firstname" value="<?= $user['firstname'] ?>"  >
		</div>
	</div>

	
	<div class="row mb-3"><!-- E-mail : Adresse email de l'utilisateur -->
		<label for="email" class="col-sm-2 col-form-label"><?= lang('User.form.email.label') ?>
		</label>
		
		<div class="col-sm-10">
			<input class="form-control" type="text" name="email" id="email" value="<?= $user['email'] ?>" required  >
		</div>
	</div>
		
    <hr>
    <div class="container">
		<div class="row justify-content-around">
			<div class="col-4">
		        <button type="submit" class="btn btn-primary"><?= lang('App.form.button.save') ?></button>
        	</div>
			<div class="col-4">
            	<a href="<?= base_url('Client/Home') ?>" type="button" class="btn btn-secondary"><?= lang('App.form.button.cancel') ?></a>
			</div>
        </div>
    </div>

<?php
echo form_close('');
?>

</section>