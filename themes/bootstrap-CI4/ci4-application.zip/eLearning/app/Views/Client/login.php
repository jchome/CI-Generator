<!doctype html>
<html>

<head>
    <title>YouDance - Welcome</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />

    <!-- Bootstrap icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css" />

    <!-- Google font Montserrat width = 900 -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:900" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?= base_url() ?>/css/client.css">

</head>

<body>
    <section>
        <div class="fullscreen">

            <div class="container">
                <div class="col-lg-6 offset-lg-3 col-md-8 offset-md-2 col-sm-12">
                    <div class="logo mb-4">
                        <img class="img-fluid" src="<?= base_url() ?>/images/logo.jpg">
                    </div>
                    <h1 class="logo mb-4">
                        YouDance
                    </h1>
                    <form action="<?= base_url() ?>/Client/Login" method="POST" class="row row-cols-lg-auto align-items-center">
                        <input type="hidden" name="formSend" value="true" />
                        <div class="col-12 mb-2">
                            <label class="visually-hidden" for="inlineFormInputGroupUsername">Username</label>
                            <div class="input-group">
                                <div class="input-group-text">@</div>
                                <input type="text" name="login" class="form-control" id="inlineFormInputGroupUsername" placeholder="email">
                            </div>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="visually-hidden" for="inputPassword">Password</label>
                            <div class="input-group">
                                <div class="input-group-text">
                                    <i class="bi bi-lock-fill"></i>
                                </div>
                                <input type="password" name="password" class="form-control" id="inputPassword" placeholder="password">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="d-grid gap-2 col-6 mx-auto">
                                <button type="submit" class="btn-lg btn-primary">Connexion</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="text-end mt-3">
                    <a href="#" data-bs-toggle="modal" data-bs-target="#forgotPasswordModal"><?= lang('App.form.forgotPassword') ?></a>
                </div>
            </div>

        </div>
    </section>
    

    <div class="modal fade" id="forgotPasswordModal" tabindex="-1" aria-labelledby="forgotPasswordModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="<?= base_url() ?>/Client/Login/lostPassword" name="lostPassword" id="lostPassword" class="signin-form" method="POST" onsubmit="return checkValidity();">
                <div class="modal-header">
                    <h5 class="modal-title" id="forgotPasswordModalLabel"><?= lang('App.form.forgotPassword') ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?= lang('App.form.button.close') ?>"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="formSend" value="true" />
                    <?= csrf_field() ?>

                    <div class="form-group mb-3">
                        <label class="label" for="email"><?= lang('App.message.type_your_email') ?></label>
                        <input type="text" class="form-control" placeholder="<?= lang('App.form.email') ?>" name="email" id="email" required>
                        <div class="col-md-12">
                            <span id="error-email" style="color: red; display: none;"><?= lang('App.message.invalid_email') ?></span>
                            &nbsp;
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?= lang('App.form.button.close') ?></button>
                    <button type="submit" class="btn btn-primary"> <?= lang('App.form.button.next') ?> </button>
                </div>
            </form>
        </div>
    </div>
    </div>


<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" 
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

<!-- jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>


<script language="javascript">
$('#lostPassword').submit(function(e) {
    $("#error-email").hide();
    var email = $("#email").val();
    if(email == ""){
        return false;
    }
    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    if(emailReg.test( email )){
        // avoid to execute the actual submit of the form.
        e.preventDefault();
        var form = $(this);
        var actionUrl = form.attr('action');


        $.ajax({
            type: "POST",
            url: actionUrl,
            data: form.serialize(), // serializes the form's elements.
            success: function(data) {
                // Purge email
                $("#email").val("");
                if(! data.result){
                    alert("Il semble qu'il y ait une erreur lors de l'envoi de l'email.");
                }
            }
        });
    }else
    {
        $("#error-email").show();
    }
    return false;
});
</script>

</body>

</html>