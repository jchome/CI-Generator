<!doctype html>
<html>
<head>
    <title>CodeIgniter Tutorial</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">

    <!-- Optional theme -->
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="/css/custom.css" />
    <link rel="stylesheet" href="/css/main.css" />

</head>
<body>
