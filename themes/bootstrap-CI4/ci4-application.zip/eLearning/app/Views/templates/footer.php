
<!-- jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

<!-- Latest compiled and minified JavaScript -->
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script src="'.base_url().'www/js/bootstrap-typeahead.js"></script>
<!-- GoogleMaps API - ->
<script src="https://maps.googleapis.com/maps/api/js?libraries=drawing,places"></script -->

</body>
</html>