<?php 

namespace App\Controllers\Client;

class Home extends \App\Controllers\BaseController {

	public function index(){
		helper(['database']);
		
        $session = session();
        if( $session->get('user_id') == null){
            return redirect()->to('Client/login');
        }
		$userId = $session->get('user_id');

		$orderBy = 'level';
		$asc = 'asc';
		$limit = 10;
		$offset = 0;
		$pager = \Config\Services::pager();

		$this->trainingModel = new \App\Models\TrainingModel();
		// Get trainings only for the user grants
		$db = db_connect();
		$builder = $db->table('training');
		$builder->distinct('training.id');
		$builder->select('training.*');
		$builder->join('positionCourseTraining', 'training.id = positionCourseTraining.training');
		$builder->join('course', 'course.id = positionCourseTraining.course');
		$builder->join('autorisationuser', 'course.access = autorisationuser.access');
		$builder->where('autorisationuser.user', $userId);
		$listTrainings = $builder->get()->getResultArray();
		$data['trainings'] = $listTrainings;
		
		/*$data['trainings'] = $this->trainingModel
			->orderBy($orderBy, $asc)->paginate($limit, 'bootstrap', null, $offset);
		$data['pager'] = $this->trainingModel->pager;
		*/

		$this->skillModel = new \App\Models\SkillModel();
		$data['skillCollection'] = index_data($this->skillModel->orderBy('title', 'asc')
			->findAll(), 'id');

        return $this->view('Client/home', $data);

    }

	public function logout(){
        log_message('debug','[Home.php] : START logout');
		$session = session();

		// Reset the token
		$this->userModel = new \App\Models\UserModel();
		$user = $this->userModel->find($session->get('user_id'));
		$user['token'] = "Disconnected";
		$this->userModel->update($user['id'], $user);

		$session->remove('user_name');
		$session->remove('user_id');
		return redirect()->to('Client/Login'); 
	}

	public function view($page, $data = [])
	{
		if (! is_file(APPPATH . 'Views/' . $page . '.php')) {
			// Whoops, we don't have a page for that!
			throw new \CodeIgniter\Exceptions\PageNotFoundException($page);
		}

		echo view('Client/headerHome', $data);
		echo view($page, $data);
		echo view('Client/footer', $data);
	}

}
?>