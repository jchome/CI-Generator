<?php 

namespace App\Controllers\Client;

use CodeIgniter\API\ResponseTrait;

class Login extends \App\Controllers\BaseController {

	use ResponseTrait;

	public function index(){
        
        log_message('debug','[Login.php] : START');
		helper(['form', 'security']);
		$formSend = $this->request->getPost('formSend');

		$session = session();

		// on est déjà connecté et on repart sur l'accueil
		if($formSend == ""){
			log_message('debug','[Login.php] : The form is not sent');
			// The form is not sent
		 	if( $session->get('user_id') != null){
                return redirect()->to('Client/home');
			 }else{
				log_message('debug','[Login.php] : User already connected');
				return $this->view('Client/login');
			 }
		}

		if (! $this->validate([
			'login' => 'required',
			'password' => 'required',
		])) {
			log_message('debug','[Login.php] : no parameter.');
            return $this->view('Client/login');
		}
		$login = $this->request->getPost('login'); 
		$password = $this->request->getPost('password');
		$data = Array();
		log_message('info','[Login.php] : login='.$login);
		
        $this->userModel = new \App\Models\UserModel();
        $allUsers = $this->userModel->where('email', $login)->findAll();
        if(sizeOf($allUsers) != 1){
            $data['message'] = 'Identifiant ['.$login.'] ou mot de passe incorrect...';
            log_message('debug','[Login.php] : user NOT connected');
            $session->setFlashdata('error', 'Identifiant ['.$login.'] ou mot de passe incorrect...');
            return $this->view('Client/login', $data);
        }
        $user = end($allUsers);

        // check password
        if(! verify($password, $user['password'])){
            $data['message'] = 'Identifiant ['.$login.'] ou mot de passe incorrect...';
            log_message('debug','[Login.php] : user NOT connected');
            $session->setFlashdata('error', 'Identifiant ['.$login.'] ou mot de passe incorrect...');
            return $this->view('welcome', $data);
        }
		if($user['profile'] != 'CUSTOMER'){
            $data['message'] = 'Utilisateur ['.$login.'] n est pas CUSTOMER...';
			log_message('debug','[Login.php] : user is not CUSTOMER');
            $session->setFlashdata('error', 'Utilisateur ['.$login.'] n est pas CUSTOMER...');
            return $this->view('welcome', $data);
		}

        $session->set('user_name', $user['firstname'] . ' ' . $user['name']);
        $session->set('user_id', $user['id']);
		
        log_message('debug','[Login.php] : user connected: '. $login);

        $ipAddress = ""; //$this->request->getIPAddress();
        $user['token'] = generateToken($user['id'], $ipAddress);
        $session->set('user_token', $user['token']);
        $this->userModel->update($user['id'], $user);

        $session->setFlashdata('token', $user['token']);
        return redirect()->to('Client/home');
        
    }

	public function lostPassword(){

		helper(['form', 'security']);
		$formSend = $this->request->getPost('formSend');

		if($formSend == ""){
			return $this->respond([
				'text' => 'No parameter',
				'type' => 'error'
			], 500);
		}

		$email = $this->request->getPost('email'); 
		$rules = [
			"email" => "required|valid_email",
		];
		if (!$this->validate($rules)) {
			return $this->respond([
				'text' => 'invalid email',
				'type' => 'error'
			], 500);
		}



		// Find the user
		$this->userModel = new \App\Models\UserModel();
		$allUsers = $this->userModel->where('email', $email)
			->where('profile', 'CUSTOMER')
			->findAll();

		if(sizeOf($allUsers) != 1){
			return $this->respond([
				'text' => 'email not found(' . sizeOf($allUsers) . ')',
				'type' => 'error'
			], 404);
		}

		$user = end($allUsers);
		// Set a new token
		$user['token'] = generateToken($user['id']);
		$this->userModel->update($user['id'], $user);
		$result = $this->sendPassword($user['email'], $user['login'], $user['token']);


		return $this->respond([
			'text' => 'ok',
			'email' => $email,
			'result' => $result,
			'link' => base_url() . 'Client/Login/newPassword?token=' . $user['token']
		]);
	}


	private function view($page, $data = [], $title = "Login") {
		if (! is_file(APPPATH . 'Views/' . $page . '.php')) {
			// Whoops, we don't have a page for that!
			throw new \CodeIgniter\Exceptions\PageNotFoundException($page);
		}

		$data['title'] = "Login";
		echo view($page, $data);
	}


	private function sendPassword($to, $login, $token){
		$subject = '[YouDance] Mot de passe oublié';
		$footer_message = '<p style="color: #555; font-size:8px;border-top: 1px solid #ccc;'.
				'margin-top:20px;padding-top: 10px;">'.
				'<span style="margin-left:10px;">Message envoyé automatiquement - ne pas répondre</span></p>';
		$link = base_url() . '/Client/Login/newPassword?token=' . $token;
		$message = '<html><body><p>Bonjour, <br>'.
				'Vous avez demandé un changement de mot de passe pour le site <a href="'.base_url().'">'.base_url().'</a>.<br>'.
				'Veuillez cliquer sur ce lien pour effectuer le changement : <br>'. 
				'<a href="'.$link.'">Changer mon mot de passe</a><br><br>'.
				'Lien : '. $link . '<br><br>'.
				$footer_message.
				'</body></html>';
	
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
	
		// Additional headers
		$headers .= 'To: '. /*$to*/ "julien@localhost" . "\r\n".
				'From: no-reply <julien.coron@gmail.com>' . "\r\n";
		return mail($to, $subject, $message, $headers);
	}

	public function newPassword(){
		helper(['form', 'security']);
		$token = $this->request->getVar('token');

		$this->userModel = new \App\Models\UserModel();
		$allUsers = $this->userModel->where('token', $token)
			->where('profile', 'CUSTOMER')
			->findAll();
			
		$data = [];
		$data['user'] = [];
		if(sizeOf($allUsers) != 1){
			$data['result'] = false;
			return $this->view('Client/resetPassword', $data);
		}

		$user = end($allUsers);

		// Extract token data
		$data['result'] = check_token($token, $user['id']);
		if($data['result']){
			$data['user'] = $user;
		}
		return $this->view('Client/resetPassword', $data);
	}
	
}