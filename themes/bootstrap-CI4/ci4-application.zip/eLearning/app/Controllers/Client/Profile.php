<?php 

namespace App\Controllers\Client;

class Profile extends \App\Controllers\BaseController {

	public function index(){
		helper(['form', 'database']);
		
        $session = session();
		$userId = $session->get('user_id');

        if( $userId == null){
            return redirect()->to('Client/login');
        }

		// Get the user
		$userModel = new \App\Models\UserModel();
		$user = $userModel->find($userId);

		$data['user'] = $user;

		$data['back'] = base_url("Client/Home");
		$data['title'] = "Mon compte";

        return $this->view('Client/profile', $data);

    }

	public function save(){

		$validation =  \Config\Services::validation();
		
		if (! $this->validate([

			'name' => 'trim|required',
			'firstname' => 'trim',
			'email' => 'trim|required',
		])) {
			log_message('debug','[Profile.php] : Error in the form !');
			session()->setFlashData('error', $validation->listErrors());
			return redirect()->to('Client/Profile');
		}
		
		// Mise a jour des donnees en base
		$session = session();
		$this->userModel = new \App\Models\UserModel();
		$key = $session->get('user_id');
		$oldModel = $this->userModel->find($key);

		$data = [

			'id' => $oldModel['id'],
			'name' => $this->request->getPost('name'),
			'firstname' => $this->request->getPost('firstname'),
			'login' => $oldModel['login'],
			'email' => $this->request->getPost('email'),
			'password' => $oldModel['password'],
			'profile' => $oldModel['profile'],
			'token' => $oldModel['token'],
		];

		$this->userModel->update($key, $data);
		return redirect()->to('Client/Home');
	}

	public function view($page, $data = [])
	{
		if (! is_file(APPPATH . 'Views/' . $page . '.php')) {
			// Whoops, we don't have a page for that!
			throw new \CodeIgniter\Exceptions\PageNotFoundException($page);
		}

		echo view('Client/headerPage', $data);
		echo view($page, $data);
		echo view('Client/footer', $data);
	}

}
?>