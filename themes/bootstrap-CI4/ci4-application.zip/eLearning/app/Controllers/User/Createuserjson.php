<?php

/*
 * Created by generator
 * 
 */
namespace App\Controllers\User;

class CreateUserJson extends \App\Controllers\BaseController {
	
	/**
	 * page de creation d'un user
	 */	
	public function index(){
		$data = Array();
		// Recuperation des objets references
		$data["enum_profile"] = array( "ADMIN" => "Administrateur","CUSTOMER" => "Utilisateur client");

		$this->load->view('user/createuser_fancyview', $data);
	}
	
	/**
	 * Ajout d'un User
	 */
	public function add(){
	
		// Insertion en base
		$model = new UserModel();
		$model->id = $this->input->post('id'); 
		$model->name = $this->input->post('name'); 
		$model->firstname = $this->input->post('firstname'); 
		$model->login = $this->input->post('login'); 
		$model->email = $this->input->post('email'); 
		$model->password = $this->input->post('password'); 
		$model->profile = $this->input->post('profile'); 
		$model->token = $this->input->post('token'); 
		$this->userservice->insertNew($this->db, $model);

		$data['user'] = $model;
		$this->load->view('json/jsonifyData_view', $data);
	}
}
?>
