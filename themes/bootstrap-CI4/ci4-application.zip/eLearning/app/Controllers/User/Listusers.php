<?php
/*
 * Created by generator
 *
 */
namespace App\Controllers\User;

class ListUsers extends \App\Controllers\BaseController {

	/**
	 * Affichage des Users
	 */
	public function index($orderBy = null, $asc = null, $offset = 0){

		if(session()->get('user_name') == "") {
			return redirect()->to('welcome/index');
		}
		
		helper(['database']);

		// preparer le tri
		if($orderBy == null) {
			$orderBy = 'name';
		}
		if($asc == null) {
			$asc = 'asc';
		}
		$data['orderBy'] = $orderBy;
		$data['asc'] = $asc;
		$limit = 10;
		$pager = \Config\Services::pager();
		// recuperation des donnees
		$userModel = new \App\Models\UserModel();

		$data['users'] = $userModel
			->orderBy($orderBy, $asc)->paginate($limit, 'bootstrap', null, $offset);
		$data['pager'] = $userModel->pager;


		$data["enum_profile"] = array("ADMIN" => "Administrateur","CUSTOMER" => "Utilisateur client");

		return $this->view('User/listusers', $data);
	}

	
	/**
	 * Suppression d'un User
	 * @param $id identifiant a supprimer
	 */
	function delete($id){
		$userModel = new \App\Models\UserModel();
		$userModel->delete($id);
		session()->setFlashData('msg_confirm', lang('User.message.confirm.deleted'));
		return redirect()->to('User/listusers/index'); 
	}

	public function view($page, $data = [])
	{
		if (! is_file(APPPATH . 'Views/' . $page . '.php')) {
			print("Cannot open view to ". $page);
			// Whoops, we don't have a page for that!
			throw new \CodeIgniter\Exceptions\PageNotFoundException($page);
		}

		echo view('templates/header', ["menu" => "User"]);
		echo view($page, $data);
		echo view('templates/footer');
	}

}
?>
