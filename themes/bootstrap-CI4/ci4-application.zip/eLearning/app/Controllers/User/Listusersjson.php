<?php
/*
 * Created by generator
 *
 */
namespace App\Controllers\User;

use CodeIgniter\API\ResponseTrait;

class ListUsersJson extends \App\Controllers\BaseController {

	use ResponseTrait;

	/**
	 * Affichage des Users
	 */
	public function index($orderBy = 'name', $asc = 'asc', $offset = 0){
		helper(['database']);

		// preparer le tri
		$data['orderBy'] = $orderBy;
		$data['asc'] = $asc;
		$limit = 10;
		$pager = \Config\Services::pager();
		// recuperation des donnees
		$this->userModel = new \App\Models\UserModel();

		$data['users'] = $this->userModel
			->orderBy($orderBy, $asc)->paginate($limit, 'bootstrap', null, $offset);
		$data['pager'] = $this->userModel->pager;

		return $this->respond([
			'text' => 'ok',
			'data' => $data
		]);

	}


	public function findBy_id($id, $orderBy = null, $limit = 50, $offset = 0){
		// recuperation des donnees
		$userModel = new \App\Models\UserModel();
		$result = $userModel->where('id', $id)->findAll();
		return $this->respond([
			'text' => 'ok',
			'data' => $result
		]);
	}
	public function findBy_name($name, $orderBy = null, $limit = 50, $offset = 0){
		// recuperation des donnees
		$userModel = new \App\Models\UserModel();
		$result = $userModel->where('name', $name)->findAll();
		return $this->respond([
			'text' => 'ok',
			'data' => $result
		]);
	}
	public function findBy_firstname($firstname, $orderBy = null, $limit = 50, $offset = 0){
		// recuperation des donnees
		$userModel = new \App\Models\UserModel();
		$result = $userModel->where('firstname', $firstname)->findAll();
		return $this->respond([
			'text' => 'ok',
			'data' => $result
		]);
	}
	public function findBy_login($login, $orderBy = null, $limit = 50, $offset = 0){
		// recuperation des donnees
		$userModel = new \App\Models\UserModel();
		$result = $userModel->where('login', $login)->findAll();
		return $this->respond([
			'text' => 'ok',
			'data' => $result
		]);
	}
	public function findBy_email($email, $orderBy = null, $limit = 50, $offset = 0){
		// recuperation des donnees
		$userModel = new \App\Models\UserModel();
		$result = $userModel->where('email', $email)->findAll();
		return $this->respond([
			'text' => 'ok',
			'data' => $result
		]);
	}
	public function findBy_password($password, $orderBy = null, $limit = 50, $offset = 0){
		// recuperation des donnees
		$userModel = new \App\Models\UserModel();
		$result = $userModel->where('password', $password)->findAll();
		return $this->respond([
			'text' => 'ok',
			'data' => $result
		]);
	}
	public function findBy_profile($profile, $orderBy = null, $limit = 50, $offset = 0){
		// recuperation des donnees
		$userModel = new \App\Models\UserModel();
		$result = $userModel->where('profile', $profile)->findAll();
		return $this->respond([
			'text' => 'ok',
			'data' => $result
		]);
	}
	public function findBy_token($token, $orderBy = null, $limit = 50, $offset = 0){
		// recuperation des donnees
		$userModel = new \App\Models\UserModel();
		$result = $userModel->where('token', $token)->findAll();
		return $this->respond([
			'text' => 'ok',
			'data' => $result
		]);
	}




	public function findLike_name($name){
		$db      = \Config\Database::connect();
		$builder = $db->table('user');
		$builder->like('name', urldecode($name));

		$data['userCollection'] = $builder->get()->getResultArray();
		return $this->respond([
			'text' => 'ok',
			'data' => $data
		]);
	}
	public function findLike_firstname($firstname){
		$db      = \Config\Database::connect();
		$builder = $db->table('user');
		$builder->like('firstname', urldecode($firstname));

		$data['userCollection'] = $builder->get()->getResultArray();
		return $this->respond([
			'text' => 'ok',
			'data' => $data
		]);
	}
	public function findLike_login($login){
		$db      = \Config\Database::connect();
		$builder = $db->table('user');
		$builder->like('login', urldecode($login));

		$data['userCollection'] = $builder->get()->getResultArray();
		return $this->respond([
			'text' => 'ok',
			'data' => $data
		]);
	}
	public function findLike_email($email){
		$db      = \Config\Database::connect();
		$builder = $db->table('user');
		$builder->like('email', urldecode($email));

		$data['userCollection'] = $builder->get()->getResultArray();
		return $this->respond([
			'text' => 'ok',
			'data' => $data
		]);
	}
	public function findLike_token($token){
		$db      = \Config\Database::connect();
		$builder = $db->table('user');
		$builder->like('token', urldecode($token));

		$data['userCollection'] = $builder->get()->getResultArray();
		return $this->respond([
			'text' => 'ok',
			'data' => $data
		]);
	}

}
?>
