<?php
/*
 * Created by generator
 *
 */
namespace App\Controllers\User;

class EditUser extends \App\Controllers\BaseController {

	/**
	 * Affichage des infos
	 */
	public function index($id){

		if(session()->get('user_name') == "") {
			return redirect()->to('welcome/index');
		}
		
		helper(['form', 'database']);
		$this->userModel = new \App\Models\UserModel();
		$model = $this->userModel->find($id);

		$data['user'] = $model;

		return $this->view('User/edituser', $data);
	}

	/**
	 * Sauvegarde des modifications
	 */
	public function save(){
		helper(['form', 'database', 'security']);

		$validation =  \Config\Services::validation();
		
		if (! $this->validate([
'name' => 'trim|required',
			'firstname' => 'trim',
			'login' => 'trim|required',
			'email' => 'trim|required',
			'password' => 'trim|required',
			'profile' => 'trim|required',
			'token' => 'trim',
		])) {
			log_message('debug','[Edituser.php] : Error in the form !');
			session()->setFlashData('error', $validation->listErrors());
			return redirect()->to('User/edituser/index/' 
				. $this->request->getPost('id'));
		}

		// Mise a jour des donnees en base
		$this->userModel = new \App\Models\UserModel();
		$key = $this->request->getPost('id');
		$oldModel = $this->userModel->find($key);

		$data = [

			'id' => $this->request->getPost('id'),
			'name' => $this->request->getPost('name'),
			'firstname' => $this->request->getPost('firstname'),
			'login' => $this->request->getPost('login'),
			'email' => $this->request->getPost('email'),
			'password' => generateHash($this->request->getPost('password')),
			'profile' => $this->request->getPost('profile'),
			'token' => $this->request->getPost('token'),
		];

		$this->userModel->update($key, $data);
		


		session()->setFlashData('msg_confirm', lang('User.message.confirm.modified'));
		return redirect()->to('User/listusers/index');
	}


	public function view($page, $data = [])
	{
		if (! is_file(APPPATH . 'Views/' . $page . '.php')) {
			print("Cannot open view to ". $page);
			// Whoops, we don't have a page for that!
			throw new \CodeIgniter\Exceptions\PageNotFoundException($page);
		}

		echo view('templates/header', ["menu" => "User"]);
		echo view($page, $data);
		echo view('templates/footer');
	}

}
?>
