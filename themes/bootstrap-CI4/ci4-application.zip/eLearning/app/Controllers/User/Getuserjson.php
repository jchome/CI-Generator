<?php
/*
 * Created by generator
 *
 */
namespace App\Controllers\User;

class GetUserJson extends \App\Controllers\BaseController {

	/**
	 * Constructeur
	 */
	function __construct(){
		parent::__construct();
		$this->load->model('UserModel');
		$this->load->library('UserService');
		$this->load->library('session');
		$this->load->library('form_validation');
		$this->load->database();


	}



	/**
	 * Affichage des infos
	 */
	public function edit($id){
		$model = $this->userservice->getUnique($this->db, $id);
		$data['user'] = $model;
		
	
		$this->load->view('user/edituser_fancyview',$data);
	}
	
	/**
	 * Sauvegarde des modifications
	 */
	public function save(){
		$this->form_validation->set_error_delimiters('', '');

		$this->form_validation->set_rules('id', 'lang:user.form.id.label', 'trim|required');
		$this->form_validation->set_rules('name', 'lang:user.form.name.label', 'trim|required');
		$this->form_validation->set_rules('firstname', 'lang:user.form.firstname.label', 'trim');
		$this->form_validation->set_rules('login', 'lang:user.form.login.label', 'trim|required');
		$this->form_validation->set_rules('email', 'lang:user.form.email.label', 'trim|required');
		$this->form_validation->set_rules('password', 'lang:user.form.password.label', 'trim|required');
		$this->form_validation->set_rules('profile', 'lang:user.form.profile.label', 'trim|required');
		$this->form_validation->set_rules('token', 'lang:user.form.token.label', 'trim');
		
		if($this->form_validation->run() == FALSE){
			$data = Array();
			$data['data'] = Array('errors' => validation_errors());
			$this->load->view('json/jsonifyData_view', $data);
			return;
		}
		
		// Mise a jour des donnees en base
		$model = new UserModel();
		$oldModel = $this->userservice->getUnique($this->db, $this->input->post('id') );
		
		$model->id = $this->input->post('id');
		$model->name = $this->input->post('name');
		$model->firstname = $this->input->post('firstname');
		$model->login = $this->input->post('login');
		$model->email = $this->input->post('email');
		$model->password = $this->input->post('password');
		$model->profile = $this->input->post('profile');
		$model->token = $this->input->post('token');
		$this->userservice->update($this->db, $model);
		

		$data['data'] = $model;
		$this->load->view('json/jsonifyData_view', $data);
	}

	/**
	 * Suppression d'un User
	 * @param $id identifiant a supprimer
	 */
	function delete($id){
		$model = $this->userservice->getUnique($this->db, $id);


		$this->userservice->deleteByKey($this->db, $id);

		$data['data'] = $model;
		$this->load->view('json/jsonifyData_view', $data);
	}

}

?>
