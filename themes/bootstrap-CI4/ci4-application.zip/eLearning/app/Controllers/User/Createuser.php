<?php
/*
 * Created by generator
 * 
 */
namespace App\Controllers\User;

class CreateUser extends \App\Controllers\BaseController {
	
	
	/**
	 * page de creation d'un user
	 */	
	public function index(){

		if(session()->get('user_name') == "") {
			return redirect()->to('welcome/index');
		}

		helper(['form']);
		$data = $this->getData();
		return $this->view('User/createuser', $data);
	}

	/**
	 * Recuperation des objets references
	 */
	private function getData() {
		$data = Array();


		$data["enum_profile"] = array( "ADMIN" => "Administrateur","CUSTOMER" => "Utilisateur client");
		return $data;
	}
	
	/**
	 * Ajout d'un User
	 */
	public function add(){
	
		helper(['form', 'database', 'security']);
		$validation =  \Config\Services::validation();

		if (! $this->validate([

	'name' => 'trim|required',
	'firstname' => 'trim',
	'login' => 'trim|required',
	'email' => 'trim|required',
	'password' => 'trim|required',
	'profile' => 'trim|required',
	'token' => 'trim',
		])) {
			$data = $this->getData();
			$data['validation'] = $this->validator;
			$this->view('User/createuser', $data);
		}
		
		// Insertion en base
		$data = [

			'id' => $this->request->getPost('id'),
			'name' => $this->request->getPost('name'),
			'firstname' => $this->request->getPost('firstname'),
			'login' => $this->request->getPost('login'),
			'email' => $this->request->getPost('email'),
			'password' => generateHash($this->request->getPost('password')),
			'profile' => $this->request->getPost('profile'),
			'token' => $this->request->getPost('token'),
		];
		$this->userModel = new \App\Models\UserModel();
		
		$this->userModel->insert($data);
		$data['id'] = $this->userModel->getInsertID();



		
		// Recharge la page avec les nouvelles infos
		session()->setFlashData('msg_confirm', lang('User.message.confirm.added'));

		return redirect()->to('User/listusers/index');
	}


	public function view($page, $data = [])
	{
		if (! is_file(APPPATH . 'Views/' . $page . '.php')) {
			print("Cannot open view to ". $page);
			// Whoops, we don't have a page for that!
			throw new \CodeIgniter\Exceptions\PageNotFoundException($page);
		}

		echo view('templates/header', ["menu" => "User"]);
		echo view($page, $data);
		echo view('templates/footer');
	}
}
?>