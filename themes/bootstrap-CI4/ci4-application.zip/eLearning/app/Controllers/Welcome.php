<?php 

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;

class Welcome extends BaseController {
	
	use ResponseTrait;

	public function index(){
		helper(['form', 'security']);
		$formSend = $this->request->getPost('formSend');

		$session = session();

		// on est déjà connecté et on repart sur l'accueil
		if($formSend == ""){
			// The form is not sent
		 	if( $session->get('user_id') != null){
				 if($session->get('user_id') == 0){
					return redirect()->to('user/listusers/index');
				}else{
					return redirect()->to('training/listtrainings/index');
				}
			 }else{
				return $this->view('welcome');
			 }
		}

		if (! $this->validate([
			'login' => 'required',
			'password' => 'required',
		])) {
			log_message('debug','[welcome.php] : no parameter.');
			return $this->view('welcome');
		}
		
		$login = $this->request->getPost('login'); 
		$password = $this->request->getPost('password');
		$data = Array();
	
		if ($login == "admin" && $password == "Ju@aude#2021") {
			$session->set('user_name', "Admin");
			$session->set('user_id', 0);
			log_message('debug','[welcome.php] : ADMIN is connected.');
			return redirect()->to('User/Listusers/index'); 
			
		} else {
			$this->userModel = new \App\Models\UserModel();
			$allUsers = $this->userModel->where('login', $login)
				->findAll();
			if(sizeOf($allUsers) != 1){
				$data['message'] = 'Identifiant ['.$login.'] ou mot de passe incorrect...';
				log_message('debug','[welcome.php] : user NOT connected');
				$session->setFlashdata('error', 'Identifiant ['.$login.'] ou mot de passe incorrect...');
				return $this->view('welcome', $data);
			}
			$user = end($allUsers);
			// check password
			if(! verify($password, $user['password'])){
				$data['message'] = 'Identifiant ['.$login.'] ou mot de passe incorrect...';
				log_message('debug','[welcome.php] : user NOT connected');
				$session->setFlashdata('error', 'Identifiant ['.$login.'] ou mot de passe incorrect...');
				return $this->view('welcome', $data);
			}

			if($user['profile'] != 'ADMIN'){
				$data['message'] = 'Utilisateur ['.$login.'] n est pas ADMIN...';
				log_message('debug','[Login.php] : user is not ADMIN');
				$session->setFlashdata('error', 'Utilisateur ['.$login.'] n est pas ADMIN...');
				return $this->view('welcome', $data);
			}
			$session->set('user_name', $user['firstname'] . ' ' . $user['name']);
			$session->set('user_id', $user['id']);
			log_message('debug','[welcome.php] : user connected: '. $login);
			
			// Add the token for the user
			$ipAddress = ""; //$this->request->getIPAddress();
			$user['token'] = generateToken($user['id'], $ipAddress);
			$session->set('user_token', $user['token']);
			$this->userModel->update($user['id'], $user);

			$session->setFlashdata('token', $user['token']);
			return redirect()->to('Training/listtrainings/index');
			
		}
		
	}

	/**
	 * Return a json message
	 */
	public function resetPassword(){

		helper(['form']);
		$formSend = $this->request->getPost('formSend');
		if($formSend == ""){
			return $this->respond([
				'text' => 'No parameter',
				'type' => 'error'
			], 500);
		}

		$email = $this->request->getPost('email'); 
		$rules = [
			"email" => "required|valid_email",
		];
		if (!$this->validate($rules)) {
			return $this->respond([
				'text' => 'invalid email',
				'type' => 'error'
			], 500);
		}

		// Find the user
		$this->userModel = new \App\Models\UserModel();
		$allUsers = $this->userModel->where('email', $email)->findAll();

		if(sizeOf($allUsers) != 1){
			return $this->respond([
				'text' => 'email not found(' . sizeOf($allUsers) . ')',
				'type' => 'error'
			], 404);
		}

		$user = end($allUsers);
		$this->sendPassword($user['email'], $user['login'], $user['password']);

		return $this->respond([
			'text' => 'ok',
			'email' => $email
		]);
	}

	public function view($page, $data = [])
	{
		if (! is_file(APPPATH . 'Views/pages/' . $page . '.php')) {
			// Whoops, we don't have a page for that!
			throw new \CodeIgniter\Exceptions\PageNotFoundException($page);
		}

		$data['title'] = "Welcome";
		echo view('pages/' . $page, $data);
	}
	
	
	/**
	 * Deconnexion
	 */
	function logout(){
		$session = session();

		// Reset the token
		$this->userModel = new \App\Models\UserModel();
		$user = $this->userModel->find($session->get('user_id'));
		if($user){
			$user['token'] = "Not available";
			$this->userModel->update($user['id'], $user);
		}

		$session->remove('user_name');
		$session->remove('user_id');
		return redirect()->to('welcome/index'); 
	}


	private function sendPassword($to, $login, $password){
		$subject = '[Dummy] Mot de passe oublié';
		$footer_message = '<p style="color: #555; font-size:8px;border-top: 1px solid #ccc;'.
				'margin-top:20px;padding-top: 10px;">'.
				'<span style="margin-left:10px;">Message envoyé automatiquement - ne pas répondre</span></p>';
		
		$message = '<html><body><p>Bonjour, <br>'.
				'Voici vos identifiants de connexion à <a href="'.base_url().'">'.base_url().'</a> : <br>'.
				'<ul><li>identifiant : '. $login . '</li>'. 
				'<li>Mot de passe : '.$password .'</li></ul>'.
				$footer_message.
				'</body></html>';
	
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
	
		// Additional headers
		$headers .= 'To: '. $to . "\r\n".
				'From: no-reply <jc.specs@free.fr>' . "\r\n";
		return mail($to, $subject, $message, $headers);
	}

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */