<?php 

namespace App\Controllers;

class Welcome extends BaseController {
	
	
	public function index(){

		helper(['form', 'url']);

		$formSend = $this->request->getPost('formSend');

		$session = session();

		// on est déjà connecté et on repart sur l'accueil
		if($formSend == ""){
			// The form is not sent
		 	if( $session->get('user_id') != null){
				 if($session->get('user_id') == 0){
					return redirect()->to('user/listusers/index');
				}else{
					return redirect()->to('welcome_connected');
				}
			 }else{
				return $this->view('welcome');
			 }
		}

		if (! $this->validate([
			'login' => 'required',
			'password' => 'required',
		])) {
			log_message('debug','[welcome.php] : no parameter.');
			return $this->view('welcome');
		}
		
		
		$login = $this->request->getPost('login'); 
		$password = $this->request->getPost('password');
		$data = Array();
	
		if ($login == "admin" && $password == "admin") {
			
			$session->set('user_name', "Admin");
			$session->set('user_id', 0);
			log_message('debug','[welcome.php] : ADMIN is connected.');
			return redirect()->to('user/listusers/index'); 
			
		} else {
			/*
			if( $login == "" && $password == "") {
				if($formSend == "true") {
					$data['message'] = 'Veuillez saisir un identifiant et un mot de passe';
				}
				$this->load->view('welcome_message',$data);
			} else {
				$criteria = Array( new Criteria('usrlblgn', Criteria::$EQ, $login),
						new Criteria('usrlbpwd', Criteria::$EQ, $password)
						);
				$allUsers = $this->userservice->getAllByCrietria($this->db, $criteria);
				if(sizeOf($allUsers) == 1){
					$user = end($allUsers);
					$this->session->set_userdata('user_name', $user->usrlbnom);
					$this->session->set_userdata('user_id', $user->usridusr);
					log_message('debug','[welcome.php] : user connected: '. $user->usrlbnom);
					redirect('voyage/listvoyages/index');
				}else{
					$data['message'] = 'Identifiant ['.$login.'] ou mot de passe incorrect...';
					log_message('debug','[welcome.php] : user NOT connected');
					$this->load->view('welcome_message',$data);
				}
				
			}
			*/
		}
		
	}

	public function view($page = 'welcome')
	{
		if (! is_file(APPPATH . 'Views/pages/' . $page . '.php')) {
			// Whoops, we don't have a page for that!
			throw new \CodeIgniter\Exceptions\PageNotFoundException($page);
		}

		$data['title'] = ucfirst($page); // Capitalize the first letter

		echo view('templates/header', $data);
		echo view('pages/' . $page, $data);
		echo view('templates/footer', $data);
	}
	
	
	/**
	 * Deconnexion
	 */
	function logout(){
		$session = session();
		$session->remove('user_name');
		$session->remove('user_id');
		return redirect()->to('welcome/index'); 
	}

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */