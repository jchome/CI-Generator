/* Javascript for edititineraire_view.php */










//$("#itiiditi").get(0).setCustomValidity('Champ requis');
//$("#idilbnom").get(0).setCustomValidity('Champ requis');
//$("#itiidvoy").get(0).setCustomValidity('Champ requis');
//$("#itinuord").get(0).setCustomValidity('Champ requis');
