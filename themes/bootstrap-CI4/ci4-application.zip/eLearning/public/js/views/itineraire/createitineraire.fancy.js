/* Javascript for createitineraire_fancyview.php */


