/* Javascript for listpartages_view.php */


