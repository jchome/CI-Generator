/* Javascript for editpartage_view.php */










//$("#paridpar").get(0).setCustomValidity('Champ requis');
//$("#paridvoy").get(0).setCustomValidity('Champ requis');
//$("#paridami").get(0).setCustomValidity('Champ requis');
