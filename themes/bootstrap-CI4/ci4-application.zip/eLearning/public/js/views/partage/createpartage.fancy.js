/* Javascript for createpartage_fancyview.php */


