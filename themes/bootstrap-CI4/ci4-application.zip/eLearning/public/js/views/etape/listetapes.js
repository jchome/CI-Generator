/* Javascript for listetapes_view.php */


