/* Javascript for createetape_fancyview.php */


