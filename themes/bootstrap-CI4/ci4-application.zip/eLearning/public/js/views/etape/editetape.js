/* Javascript for editetape_view.php */










//$("#etpidetp").get(0).setCustomValidity('Champ requis');
//$("#etplbnom").get(0).setCustomValidity('Champ requis');
//$("#etpnulat").get(0).setCustomValidity('Champ requis');
//$("#etpnulon").get(0).setCustomValidity('Champ requis');
//$("#etpiditi").get(0).setCustomValidity('Champ requis');
//$("#etpnuord").get(0).setCustomValidity('Champ requis');
