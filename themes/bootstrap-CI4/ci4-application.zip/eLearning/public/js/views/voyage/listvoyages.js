/* Javascript for listvoyages_view.php */


