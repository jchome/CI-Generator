/* Javascript for createvoyage_fancyview.php */


