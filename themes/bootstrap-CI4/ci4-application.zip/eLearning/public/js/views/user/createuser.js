/* Javascript for createuser_view.php */








//$("#id").get(0).setCustomValidity('Champ requis');
//$("#name").get(0).setCustomValidity('Champ requis');
//$("#login").get(0).setCustomValidity('Champ requis');
//$("#email").get(0).setCustomValidity('Champ requis');
//$("#password").get(0).setCustomValidity('Champ requis');
//$("#profile").get(0).setCustomValidity('Champ requis');


