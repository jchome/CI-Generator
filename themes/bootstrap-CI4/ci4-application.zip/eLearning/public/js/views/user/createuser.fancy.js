/* Javascript for createuser_fancyview.php */


