$( document ).ready(function() {
    /*if(categoryId == ""){
        const modal = new bootstrap.Modal('#filterModal', {});
        modal.show();
    }*/
    if(flashData["info"]){
        displayToast('#liveToast', flashData["info"], 'bg-success');
    }
    if(flashData["error"]){
        displayToast('#liveToast', flashData["error"], 'bg-danger');
    }
});