
function login() {
    const circle = $('.circle');
    const button = $('.button');
    circle.css({
        left: button.offset().left + (button.width() / 2) + circle.width() / 2,
        top: button.offset().top + (button.height() / 2) + circle.height() / 2,
    });


    // Start the request
    data = {
        'login': $('#login').val(),
        'password': $('#password').val(),
        'formSend': true,
    };
    data[$('#csrf_token').attr('name')] = $('#csrf_token').val();
    $.ajax({
        url: base_url() + "App/Security/sign_in",
        method: "POST",
        data: data,
        headers: {
            'X-YouDance': 'YouDance-App',
            'X-Requested-With': 'XMLHttpRequest',
        },
        beforeSend: function (f) {
            button.addClass('animate');
            $('.sign-in').addClass('animate');
            $('.loader').addClass('animate');
        },
        success: function (data) {
            if(data.status === 'ok'){
                circle.show();
                circle.addClass('grow');
                // Wait a little time before removing the form
                setTimeout(() => {
                    $('.button-container, .inputs, .img-splash, #forgotPasswordLink').hide();
                    document.location.href = base_url() + "App/Home/welcome";
                }, 1000);
            }else{
                button.removeClass('animate');
                $('.sign-in').removeClass('animate');
                $('.loader').removeClass('animate');

                $('#liveToast .toast-body').html(data.message);
                const toastBootstrap = bootstrap.Toast.getOrCreateInstance($('#liveToast').get(0));
                toastBootstrap.show();
            }

        }
    });

}


$('#lostPassword').submit(function(e) {
    $("#error-email").hide();
    var email = $("#email").val();
    if(email == ""){
        return false;
    }
    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    if(emailReg.test( email )){
        // avoid to execute the actual submit of the form.
        e.preventDefault();
        var form = $(this);
        var actionUrl = form.attr('action');


        $.ajax({
            type: "POST",
            url: actionUrl,
            data: form.serialize(), // serializes the form's elements.
            success: function(data) {
                // Purge email
                $("#email").val("");
                if(! data.result){
                    alert("Il semble qu'il y ait une erreur lors de l'envoi de l'email.");
                }
            }
        });
    }else
    {
        $("#error-email").show();
    }
    return false;
});