
$( document ).ready(function() {

    makeItShine( $('.make-it-shine-explode'), {
        direction: "EXPLODE",
        amount: 30,
    });
    makeItShine( $('.make-it-shine-up'), {
        direction: "UP",
        amount: 30,
    });
    
});

function makeItShine(jqElt, conf){
    if(jqElt.length == 0){
        return;
    }
    direction = conf.direction || "UP";
    amount = conf.amount || 10;
    
    for(let i=0;i<amount;i++){
        prepareShine(jqElt, direction, i);
    }
}

function prepareShine(jqElt, direction, index){
    const installationTimer = Math.round((Math.random() * 5000)); // Start animation between now and 5 s
    
    setTimeout(() => {
        createShine(jqElt, direction, index);
    }, installationTimer);
}

function createShine(jqElt, direction, index){
    const pos = jqElt.position();
    const offset = jqElt.offset();
    const width = jqElt.outerWidth();
    const height = jqElt.outerHeight();

    // Default values
    var finalX = 10; // Half width of the star
    var finalY = 10; // Half height of the star
    var posY = height;
    var posX = Math.round(pos.left + (Math.random() * width));
    if(direction == "UP"){
        finalY = Math.round((-50 * Math.random() ));
        posY = Math.round((Math.random() * height * 0.5)) - (height * 0.5);
    }else if(direction == "DOWN"){
        finalY = Math.round((50 * Math.random() )) + 20;
        posY = Math.round((Math.random() * height * 0.5)) + (height * 0.9);
    }else if(direction == "EXPLODE"){
        explosionLength = 100;
        posX = (Math.round((width * Math.random() )) - width/2)/10; // between -width/2 to width/2
        posY = (Math.round((height * Math.random() )) - height/2)/10 ; // between -height/2 to height/2
        if(posX < 0){
            finalX = Math.round(((0-explosionLength) * Math.random() ));
        }else{
            finalX = Math.round((explosionLength * Math.random() ));
        }
        if(posY < 0){
            finalY = Math.round(((0-explosionLength) * Math.random() ));
        }else{
            finalY = Math.round((explosionLength * Math.random() ));
        }
        posX += offset.left + width/2 - 16;
        posY += pos.top + height/2 - 16;
        
    }else if(direction == "STATIC"){
        posX = pos.left + Math.round((width * Math.random() )) ; // between pos.left and pos.left+width
        posY = pos.top + Math.round((height * Math.random() ))  ; // between pos.top and pos.top+height
        finalX = 10;
        finalY = 10;
    }
    //console.log(posX, posY);
    const starElt = $(`<div class="star" style="top: ${posY}px; left: ${posX}px" id="star_${index}"></div>`).appendTo(jqElt.parent());

    const duration = Math.round((1000 * Math.random() )) + 1500; // between 1500 and 2500 ms
    starElt.transition({x: finalX, y: finalY, opacity: 0, width: 2, height: 2}, duration, 'ease');
    setTimeout(() => {
        // At the end of the 'duration' timer, remove this shine
        starElt.remove();
        // Add a new shine
        createShine(jqElt, direction, index);
    }, duration);
    
}
