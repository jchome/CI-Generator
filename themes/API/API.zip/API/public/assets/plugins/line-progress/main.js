$( document ).ready(function() {

    updateProgressLineWrapper();

    $('.vertical-list').each((index, element) => {
        let percentDone = $(element).find('.part.done').length / $(element).find('.part').length;
        let progressLineElt = $(element).find('.vertical-bar');
        if(percentDone < 1) {
            percentDone += 0.3;
        }
        progressLineElt.height( percentDone * ($(element).height() - 20) );
    });
    
});

function updateProgressLineWrapper(){
    $('.progress-line-wrapper').each((index, element) => {
        let percentDone = 100 * $(element).find('.part.done').length / $(element).find('.part').length;
        let progressLineElt = $(element).find('.progress-line');
        if(percentDone == 0){
            // Half a part of the full length
            percentDone = 50 / $(element).find('.part').length;
        }
        progressLineElt.find('.progress-content').width(percentDone + '%');
    });

}