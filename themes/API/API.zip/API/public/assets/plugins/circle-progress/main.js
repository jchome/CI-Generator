$( document ).ready(function() {
    config = {
        radius: 65,
        success: {
            lineWidth: 6,
            strokeStyle: '#f58c02',
        },
        todo:{
            lineWidth: 12,
            strokeStyle: '#e0e0e0',
        }
    }

    $('.circle-progress-wrapper').each((index, element) => {
        moveParts($(element).find('.part'), $(element), config.radius);
        let percentDone = 100 * $(element).find('.part.done').length / $(element).find('.part').length;
        if(percentDone == 0){
            // Half a part of the full length
            percentDone = 50 / $(element).find('.part').length;
        }
        drawPercent($(element).find('canvas.circle-progress-bar'), percentDone, config);
    });
    
});

function drawPercent(canvasElt, percent, config){
    if(canvasElt.length == 0){
        return;
    }
    const canvas = canvasElt.get(0);
    const ctx = canvas.getContext("2d");
    canvas.width = canvasElt.width();
    canvas.height = canvasElt.height();
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    const startAngle = 3*Math.PI / 2;
    const angleRad = (2 * Math.PI) * (percent / 100) + 3*Math.PI / 2;

    centerOfCanvas = {x: canvas.width/2, y: canvas.height/2};

    // Draw the todo arc
    ctx.lineWidth = config.todo.lineWidth || 6;
    ctx.strokeStyle = config.todo.strokeStyle || 'black';
    ctx.beginPath();
    ctx.arc(centerOfCanvas.x, centerOfCanvas.y, config.radius, 0 , (2 * Math.PI) , 0);
    ctx.stroke();
    
    // Draw the success arc
    ctx.lineWidth = config.success.lineWidth || 6;
    ctx.strokeStyle = config.success.strokeStyle || 'black';
    ctx.beginPath();
    ctx.arc(centerOfCanvas.x, centerOfCanvas.y, config.radius, startAngle , angleRad , 0);
    ctx.stroke();
}

function moveParts(partsElts, parentElt, radius){
    const nbItems = partsElts.length;
    if(nbItems == 0){
        return;
    }
    const angleOffset = 2*Math.PI / nbItems;
    const center = { 
        x: parentElt.width()/2,
        y: parentElt.height()/2,
    };

    var angle = 3*Math.PI / 2;
    for(let i=0;i<nbItems;i++){
        var position = {
            x: center.x + (Math.cos(angle) * radius) - $(partsElts[i]).width()/2,
            y: center.y + (Math.sin(angle) * radius) - $(partsElts[i]).height()/2,
        };
        $(partsElts[i]).css('left', position.x);
        $(partsElts[i]).css('top', position.y);

        angle += angleOffset;
    }
}