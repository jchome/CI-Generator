$( document ).ready(function() {
    
    $('button.favorite').on('click', function(){
        explodeEffect($(this), {
            count: 30, 
            variations: [
                {
                    cssProperty: 'font-size',
                    min: 0.2,
                    max: 2.5,
                    unit: 'em',
                },
                {
                    cssProperty: 'color',
                    min: '#0000ff',
                    max: '#00ffff',
                    unit: 'color',
                }
            ],
            distance:{
                min: 10,
                max: 150
            }
        });
    });
    
});

function randomFloat(min, max) {
	return Math.random() * (max - min) + min;
}
function randomInt(min, max) {
	return Math.round(randomFloat(min, max));
}

function runSequence(elt, keyframesArray, duration = 1e3, easing = "linear", delay = 0) {
    let animation = elt.animate(keyframesArray, {
            duration: duration,
            easing: easing,
            delay: delay
        }
    );
    
    animation.onfinish = () => {
        elt.remove();
    };
}

function animateParticle(particle, distanceOptions){
    const distance = randomInt(distanceOptions.min, distanceOptions.max);
    const randomAngle = randomFloat(0, 2 * Math.PI);
    const dx = distance * Math.cos(randomAngle);
    const dy = distance * Math.sin(randomAngle);
    const maxRotAngle = 800; // degres
    const rotX = randomInt(0, maxRotAngle);
    const rotY = randomInt(0, maxRotAngle);
    const rotZ = randomInt(0, maxRotAngle);

    runSequence(particle, [{
            opacity: 1,
            transform: `translate(0px,0px) rotateX(0) rotateY(0) rotateZ(0)`,
        },
        {
            opacity: 1,
        },
        {
            opacity: 0.5,
        },
        {
            opacity: 0.8,
        },
        {
            opacity: 0,
            transform: `translate(${dx}px,${dy}px) rotateX(${rotX}deg) rotateY(${rotY}deg) rotateZ(${rotZ}deg)`,
        }
    ]);
}

function applyVariations(particle, variations){
    for (const variation of variations) {
        
        if(variation.unit === 'color'){
            const newColor = (new RandomColor(variation.min, variation.max)).getColor();
            particle.css(variation.cssProperty, newColor);
        }else{
            const newValue = randomFloat(variation.min, variation.max);
            particle.css(variation.cssProperty, newValue + variation.unit);
        }
    }
}

function explodeEffect(elt, options){
    const nbParticles = options.count || 10;
    const variations = options.variations;
    const distance = options.distance;
    // Move the button up of the particles
    elt.css('z-index', 10);
    const allParticles = $('.particles').children();

    // Create some objects under of the button
    const explodeZone = $(`<div class="explodeZone"></div>`).appendTo( elt.parent() );
    explodeZone.offset({
        top: elt.offset().top + elt.height()/2 + 10 - explodeZone.height()/2,
        left: elt.offset().left + elt.width()/2 + 10 - explodeZone.width()/2
    });
    for(let i=0;i<nbParticles; i++){
        var particleIndex = randomInt(0, allParticles.length-1);
        const particle = $(allParticles[particleIndex]).clone().appendTo(explodeZone);

        particle.css({
            top: explodeZone.height()/2 - particle.height()/2,
            left: explodeZone.width()/2 - particle.width()/2,
        });
        
        applyVariations(particle, variations);
        animateParticle(particle.get(0), distance);
        
    }
    
}

/* ************** */

//
// Usage : var generator = new RandomColor("#000", "rgb(0, 207, 239)").getColor();
//
// @link https://stackoverflow.com/questions/25193110/random-color-between-two-selected-rgb-colors-javascript
/**
 * 
 * @param {*} color1 
 * @param {*} color2 
 */
function RandomColor (color1, color2) {

    var _regs = {
        "hex3"  : /^#([a-f\d])([a-f\d])([a-f\d])$/i,
        "hex6"  : /^#([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i,
        "rgb"   : /^rgb\s*\(\s*([\d\.]+%?)\s*\,\s*([\d\.]+%?)\s*\,\s*([\d\.]+%?)\s*\)$/
    };

    var _obj1 = getValues(color1);
    var _obj2 = getValues(color2);

    //---Get the colors
    function getValues (color) {

        var values = false;

        for (var prop in _regs) {

            if (_regs[prop].test(color)) {

                values = {};

                values.r = color.replace(_regs[prop], "$1");
                values.g = color.replace(_regs[prop], "$2");
                values.b = color.replace(_regs[prop], "$3");

                if (prop === "rgb") {
 
                    values.r = Number(values.r);
                    values.g = Number(values.g);
                    values.b = Number(values.b);

                } else {

                    values.r = parseInt(values.r, 16);
                    values.g = parseInt(values.g, 16);
                    values.b = parseInt(values.b, 16);

                }

                break;

            }

        }

        return values;

    }

    //---str_pad
    function str_pad (str, pad_length, pad_string, pad_type) {

        var len = pad_length - str.length;
        if (len < 0) { return str };
        var pad = new Array(len + 1).join(pad_string);
        if (pad_type === "STR_PAD_LEFT") { return pad + str };
        return str + pad;

    }

    //---Get a value
    function getRandom (c1, c2, pcent) {

        var color = c1 + Math.floor((c2 - c1) * pcent);

        if (color < 0) color = 0;

	    return str_pad(color.toString(16), 2, "0", "STR_PAD_LEFT");

    }

    //---Get a random color
    this.getColor = function () {

        if (_obj1 && _obj2) {

            var random = Math.random();

            var r = getRandom(_obj1.r, _obj2.r, random);
            var g = getRandom(_obj1.g, _obj2.g, random);
            var b = getRandom(_obj1.b, _obj2.b, random);

            return "#" + r + g + b;

        }

        return false;

    };

}
