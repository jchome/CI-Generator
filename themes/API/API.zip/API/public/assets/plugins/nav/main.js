/**
Original content: 
https://codepen.io/aaroniker/pen/ydLzeg
*****
+ 5 items rather than 3
+ avoid import of SVG
*/
var currentMenu = null;
$( document ).ready(function() {
    
    currentMenu = $('input[type="radio"][checked]').data('order');

    $('input[type="radio"]').on('click', function(event){

        const thisItemNumber = parseInt($(this).data('order'));
        if(thisItemNumber == 0){
            $('.navbar-toggler').click();
            event.preventDefault();
            return;
        }

        if(currentMenu === thisItemNumber) {
            return;
        }
        if (currentMenu > thisItemNumber){
            navigateToLeft($(this).data('link'));
        }else if (currentMenu < thisItemNumber){
            navigateToRight($(this).data('link'));
        }
        currentMenu = thisItemNumber;
        
    });

    // Load the main data from the "lastPageInSession" variable
    loadLastPageInSession();
    computeSpacer();

    // On orientation changed
    $(window).on("orientationchange", function(event) {
        setTimeout(() => {
            computeSpacer();
        }, 500);
    });
    
});

// Activate the menu at the potition of the link
function updateMenuPosition(link){
    $('.tabbar input').prop('checked', false);
    if(link.indexOf('Home') > -1) {
        $('.tabbar #menu-1').prop('checked', 'checked');
        currentMenu = 0;
        return;
    }

    if(link.indexOf('Favorite') > -1) {
        $('.tabbar #menu-2').prop('checked', 'checked');
        currentMenu = 1;
        return;
    }
    if(link.indexOf('Parcours') > -1 || link.indexOf('Content') > -1) {
        $('.tabbar #menu-3').prop('checked', 'checked');
        currentMenu = 2;
        return;
    }
    if(link.indexOf('Profile') > -1) {
        $('.tabbar #menu-4').prop('checked', 'checked');
        currentMenu = 3;
        return;
    }
    if(link.indexOf('Search') > -1) {
        $('.tabbar #menu-5').prop('checked', 'checked');
        currentMenu = 4;
        return;
    }
}

function loadLastPageInSession(){
    if(typeof lastPageInSession !== 'undefined'){
        navigateToRight(base_url() + lastPageInSession);
    }
}

function computeSpacer(){
	var height = $( window ).height() 
		- $('.sticky-top').height()
		- $('.tabbar').height();
	$('#main').height(height);
}

function navigateToLeft(link, idModalToClose){
    if(!link){
        return;
    }
    // Hide the current toast
    bootstrap.Toast.getOrCreateInstance($('#liveToast').get(0)).hide();

    if(idModalToClose){
        const modal = bootstrap.Modal.getInstance($(idModalToClose).get(0));
        if(modal){
            modal.hide();
        }
    }
    
    $('#loading').show();
    $('#main').addClass('center-to-right');
    $('#loading').addClass('left-to-center');
    console.info("Navigating to " + link);

    setTimeout(() => {
        $('#main').load(link, function(){
            // After loaded
            updateMenuPosition(link);
            $('#loading').hide();
            $('#main').removeClass('center-to-right');
            $('#loading').removeClass('left-to-center');
            computeSpacer();
        });
    }, 500);
    
}

function navigateToRight(link, idModalToClose){
    if(!link){
        return;
    }
    // Hide the current toast
    bootstrap.Toast.getOrCreateInstance($('#liveToast').get(0)).hide();

    if(idModalToClose){
        const modal = bootstrap.Modal.getInstance($(idModalToClose).get(0));
        if(modal){
            modal.hide();
        }
    }
    
    $('#loading').show();
    $('#main').addClass('center-to-left');
    $('#loading').addClass('right-to-center');
    console.info("Navigating to " + link);

    setTimeout(() => {
        $('#main').load(link, function(){
            // After loaded
            updateMenuPosition(link);
            $('#loading').hide(200);
            $('#main').removeClass('center-to-left');
            $('#loading').removeClass('right-to-center');
            computeSpacer();
        });
    }, 500);
    
}

function openMenuNamed(menuName){
    $('.tabbar input[value="'+menuName+'"]').click();
}

function getCurrentMenuName(){
    const itemElt = $('.tabbar input').get(currentMenu);
    return $(itemElt).val();
}