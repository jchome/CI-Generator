function today(elt) {
  $(elt).val(new Date().toLocaleDateString(getLocale()));
  return false;
}


function applyTranslation(prefix, langId, objectId){
	const langRow = $('#lang_' + langId);
	const columns = langRow.data('columns').split(',');

	var data = {
		lang_id: langId,
		translations: {}
	};
	for (const columnName of columns) {
		var key = prefix + '.' + objectId + '.' + columnName;
		var value = langRow.find('.translation[data-column="'+columnName+'"]').val();
		data.translations[key] = value;
	}

	// Call the update of the parameter
	$.ajax({
		url: base_url() + "Admin/Translate/AjaxTranslate/save/",
		method: "POST",
		data: data,
		headers: {'X-Requested-With': 'XMLHttpRequest'},
		success: function (data) {
			console.log(data)
        },
    });
}
