../../CI-Generator/generate.py ../Assets/DesignDeploy/*.xml
