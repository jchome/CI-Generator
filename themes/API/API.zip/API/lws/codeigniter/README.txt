Here is the right place for the following directories :
 - app/
   - Config/
   - Controlers/
   - ...
   - Views/
 - vendor/
 - writable/
