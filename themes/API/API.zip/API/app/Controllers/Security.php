<?php 

namespace App\Controllers;

use App\Models\ContractModel;
use App\Models\SubscriptionModel;
use App\Models\UserModel;
use Exception;

class Security extends \App\Controllers\AjaxController {

    public function csrf(){
        $security = \Config\Services::security();

        return $this->statusOK([
            'name' => csrf_token(),
            'hash' => csrf_hash(),
        ]);
        
    }

    /**
     */
    public function token(){
        try{
            $user = $this->getAuthorizedUser();
        }catch(Exception $e){
            return $this->statusFailure($e->getMessage());
        }

        return $this->statusOK($user);
    }

    /**
     * Authenticate the user
     */
    public function sign_in(){
        log_message('debug','[Singin.php] : START');
		helper(['form', 'security']);

        if($this->request->getMethod() != 'post'){
			return $this->statusError('Methode de connexion non autorisée.');
        }
        
        /*
        if( session()->get('user_id') != null){
            session()->remove('user_id');
        }*/

        //log_message('debug','[Security.php] : POST:' . print_r($this->request->getJSON(), true));

        $this->request->getJSON();
		$login = $this->request->getPost('login'); 
		$password = $this->request->getPost('password');
        if($login == ""){
            $login = $this->request->getJsonVar('login');
        }
        if($password == ""){
            $password = $this->request->getJsonVar('password');
        }
        //log_message('debug','[Security.php] : login=' . print_r($login, true));
        if ($login == "" && $password == "") {
			log_message('debug','[Security.php] : no parameter.');
            return $this->statusError('Veuillez remplir votre identifiant et le mot de passe.');
		}

        $userModel = new UserModel();
        $allUsers = $userModel->asObject()->where('email', $login)->findAll();
        if(sizeOf($allUsers) != 1){
            log_message('debug','[Security.php] : user NOT found');
            return $this->statusError('Identifiant ['.$login.'] ou mot de passe incorrect.');
        }
        $user = end($allUsers);

        // Check password
        if($login == "admin" && strcmp($password, $user->password) != 0){
            // For admin, the password is clear
            log_message('debug','[Security.php] : password is incorrect ('.$password.' // '.$user->password.')');
            return $this->statusError('Identifiant ['.$login.'] ou mot de passe incorrect.');
        }
        if($login != "admin" && ! verify($password, $user->password)){
            // For other users, the password is hashed
            log_message('debug','[Security.php] : password is incorrect ('.$password.' // '.$user->password.')');
            return $this->statusError('Identifiant ['.$login.'] ou mot de passe incorrect.');
        }
        
        $app = $this->request->getHeaderLine('X-App');
        //log_message('debug','[Security.php] : check app:' . $app . " // " . $user->profile);
		if($user->profile == 'CUSTOMER' && $app != APP_CLIENT){
            log_message('debug','[Security.php] : user is CUSTOMER, but app is ' . $app);
            return $this->statusError('Application non valide...');
		}
		if($user->profile == 'ADMIN' && $app != APP_ADMIN){
			log_message('debug','[Security.php] : user is ADMIN, but app is ' . $app);
            return $this->statusError('Application non valide...');
		}

        //log_message('debug','[Security.php] : name: ' . $user->email);
        //log_message('debug','[Security.php] : token: ' . $user->token);
        if($user->email == "demo@me.com" && $user->token != ""){
            // Reuse the existing token
        }else{
            $ipAddress = $this->request->getIPAddress();
            $user->token = generateToken($user->id, $ipAddress);
            $user->expiration_token = computeTokenExpirationDate();
            $userModel->update($user->id, $user);
            //log_message('debug','[Security.php] : token: ' . $user->token);
        }
        /*
        session()->set('user_id', $user->id);
        session()->set('user_token', $user->token);
        session()->set('currentUser', $user);
        */

        return $this->statusOK([
            'token' => $user->token,
        ]);
    }

    public function forgotpassword(){
        if($this->request->getMethod() != 'post'){
            return $this->statusError('Methode de connexion non autorisée.');
        }
        $this->request->getJSON();
        $email = $this->request->getJsonVar('email'); 
        if($email == null || $email == ""){
            return $this->statusError('Paramètre requis : email.');
        }

        $userModel = new UserModel();
        $allUsers = $userModel->asObject()->where('email', $email)->findAll();
        if(sizeOf($allUsers) != 1){
            log_message('debug','[Security.php] : user NOT found');
            return $this->statusError("Cet email est introuvable...");
        }
        $user = end($allUsers);
        if($user->email == ""){
            return $this->statusError("Cet utilisateur n'a pas d'email...");
        }

		helper(['security']);
        $personalCode = generateRandomCode(3);
        $passToken = buildPassToken($user->id, $personalCode);
        $link = base_url("/Password/index/" . $passToken);

        $email = service('email');

        $email->setFrom(EMAIL_FROM, APP_CLIENT);
        $email->setTo($user->email);
        $email->setBCC('julien.coron@gmail.com');

        $email->setSubject('['.APP_CLIENT.'] Changement de mot de passe');
        $email->setMessage( view("forgotpassword-email", ["link" => $link]) );

        $result = $email->send();
        if($result){
            return $this->statusOK($personalCode);
        }else{
            return $this->statusError("Erreur dans le processus d'envoi d'email...");
        }

    }

    /* ***************************************************** */
    /*  GOOGLE STUFF */
    /* ***************************************************** */

    private function createGoogleClient($redirect = ""){
        require_once APPPATH. "Libraries/vendor/autoload.php";
        $googleClient = new \Google_Client();
		$googleClient->setClientId(GOOGLE_CLIENT_ID);
		$googleClient->setClientSecret(GOOGLE_CLIENT_SECRET);
		$googleClient->setRedirectUri(base_url("/Security/loginWithGoogle") );
        // Give me the email and the profile
        $scopes = array(
            \Google_Service_Oauth2::USERINFO_PROFILE,
            \Google_Service_Oauth2::USERINFO_EMAIL
        );
        $googleClient->setScopes($scopes);
        $googleClient->setState($redirect);
        return $googleClient;
    }

    /**
     * First step to open the "Authenticate with Google" window
     *
     * @return response The OK response, with the URL to open
     */
    public function getGoogleAuthUrl(){
        $redirect = $this->request->getVar('redirect');
        log_message('debug', "getGoogleAuthUrl will redirect to ".$redirect);
        $googleClient = $this->createGoogleClient($redirect);
        return $this->statusOK($googleClient->createAuthUrl());
    }

    /**
     * Called with POST method, when the google authentication finished succefully
     *
     * @return void
     */
    public function loginWithGoogle(){
        $code = $this->request->getVar('code');
        $redirectToClient = $this->request->getVar('state');
        $googleClient = $this->createGoogleClient();

        $token = $googleClient->fetchAccessTokenWithAuthCode($code);
        if(isset($token['error'])){
            log_message('debug','googleClient ERROR: ' . $token['error'] );
            return redirect()->to($redirectToClient."?error=GoogleAuthError");
        }
        $googleClient->setAccessToken($token['access_token']);
        $googleService = new \Google_Service_Oauth2($googleClient);
        $data = $googleService->userinfo->get();
        // JCO: Get GOOGLE data
        //log_message('debug','googleService->userinfo = ' . print_r($data, true) );

        $userModel = new UserModel();
        // Match the user's google email with the login in our table
        $allUsers = $userModel->asObject()->where('email', $data["email"])->findAll();
        if(sizeOf($allUsers) > 1){
            return redirect()->to($redirectToClient.'?error=notUniqueUser'); 
        }else if(sizeOf($allUsers) == 0){
            
            log_message('debug','[Security.php] : user NOT found with login='.$data["email"]);
            // Create a new user
            $newUser = [
                'email' => $data["email"], // email is unique
                'nickname' => $data["givenName"],
                'profile' => 'AUTHOR'
            ];
            $userModel->save($newUser);
            $newUser['id'] = $userModel->insertID();

            // Get the picture of the user, if possible
            if($data["picture"] != null){
                // Download the picture of the Google user
                $extension = pathinfo($data["picture"], PATHINFO_EXTENSION);
                $filename = 'content_' . $data['id'] . '_photo-'.time().'.' . $extension;
                file_put_contents(PUBLIC_PATH . 'uploads/' . $filename, file_get_contents($data["picture"]));
                $newUser['photo'] = $filename;
                $userModel->save($newUser);
            }

        }
        $user = end($allUsers);
        //log_message('debug','[Security.php] : user is '. print_r($user, true));
        
		helper(['security']);
        $ipAddress = $this->request->getIPAddress();
        $user->token = generateToken($user->id, $ipAddress);
        $user->expiration_token = computeTokenExpirationDate();
        $userModel->update($user->id, $user);

        return redirect()->to($redirectToClient.'?token='.$user->token); 

    }

}