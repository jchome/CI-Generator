<?php
namespace App\Controllers\Api\v2;

use App\Controllers\AjaxController;
use App\Models\TargetModel;
use App\Models\UserModel;

Class Auth extends AjaxController{

    public function index(){
        // Load security helper
		helper(['security']);

        $data = $this->request->getJSON(true);
        $targetKey = $data['target_key'];
        $password = $data['password'];

        $targetModel = new TargetModel();
        $targets = $targetModel->asObject()->where('key', $targetKey)->find();
        if(sizeof($targets) != 1){
            return $this->statusFailure("Target not found with key=".$targetKey);
        }
        $target = end($targets);

        $userModel = new UserModel();
        $users = $userModel->asObject()->where('id', $target->admin_id)->find();
        if(sizeof($users) != 1){
            return $this->statusFailure("User not found for target=".$targetKey);
        }
        $user = end($users);
        if(verify($password, $user->password)){
            return $this->statusOK("success");
        }else{
            return $this->statusFailure("Wrong password");
        }
    }
}