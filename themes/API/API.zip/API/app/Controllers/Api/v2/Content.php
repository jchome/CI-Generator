<?php
namespace App\Controllers\Api\v2;

use App\Controllers\AjaxController;
use App\Models\ContentModel;
use App\Models\LanguageModel;
use App\Models\TargetModel;

Class Content extends AjaxController{

    /**
     * Get a content
     *
     * @param [type] $targetKey
     * @param [type] $languageCode
     * @param [type] $contentKey
     * @return void
     */
    public function index($targetKey, $languageCode, $contentKey){
        /*log_message('debug', "Content with targetKey=".$targetKey . 
            " languageKey=".$languageCode .
            " contentKey=".$contentKey);*/
        $db = db_connect();
        $builder = $db->table('cm_content');
        
        if($contentKey != '*'){
            // Get only one content
            $query = $builder
                ->select('cm_content.data')
                ->join('cm_language', 'cm_language.id = cm_content.language_id')
                ->join('cm_target', 'cm_target.id = cm_content.target_id')
                ->where('cm_language.code', $languageCode)
                ->where('cm_target.key', $targetKey)
                ->where('cm_content.key', $contentKey)
                ->get();
            $allData = $query->getResult();
            if(sizeof($allData) == 0){
                return $this->statusError("no data");
            }
            if(sizeof($allData) == 0){
                return $this->statusError("no data");
            }
            // Get only the 'data' content
            return $this->statusOK(end($allData)->data );
        }else{
            $query = $builder
                ->select('cm_content.key, cm_content.data')
                ->join('cm_language', 'cm_language.id = cm_content.language_id')
                ->join('cm_target', 'cm_target.id = cm_content.target_id')
                ->where('cm_language.code', $languageCode)
                ->where('cm_target.key', $targetKey)
                ->get();
            $allData = $query->getResult();
            
            if(sizeof($allData) == 0){
                return $this->statusError("no data");
            }
            // Get only the 'data' content
            return $this->statusOK($allData );
        }
    }


    /**
     * Stores a content
     *
     * @return void
     */
    public function save(){
        $data = $this->request->getJSON(true);
        $targetKey = $data['target_key'];
        $languageCode = $data['language_code'];
        $contentKey = $data['content_key'];
        $contentData = $data['content_data'];

        /*log_message('debug', "Save content with targetKey=".$targetKey . 
            " languageKey=".$languageCode .
            " contentKey=".$contentKey . 
            " contentData=" .$contentData);
        */

        $targetModel = new TargetModel();
        $targets = $targetModel->asObject()->where('key', $targetKey)->find();
        if(sizeof($targets) != 1){
            return $this->statusFailure("Target not found with key=".$targetKey);
        }
        $target = end($targets);

        $languageModel = new LanguageModel();
        $languages = $languageModel->asObject()->where('code', $languageCode)->find();
        if(sizeof($languages) != 1){
            return $this->statusFailure("Language not found with code=".$languageCode);
        }
        $language = end($languages);

        $contentModel = new ContentModel();
        $contents = $contentModel->asObject()
            ->where('key', $contentKey)
            ->where('language_id', $language->id)
            ->where('target_id', $target->id)
            ->find();
        if(sizeof($contents) == 0){
            $data = [
                'target_id' => $target->id,
                'language_id' => $language->id,
                'key' => $contentKey,
                'data' => $contentData
            ];
            $contentModel->save($data);
            $data['id'] = $contentModel->getInsertID();
            return $this->statusOK($data);
        }else{
            $content = end($contents);
            $content->data = $contentData;
            $contentModel->save($content);
            return $this->statusOK($content);
        }
    }

}