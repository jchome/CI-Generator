<?php 

namespace App\Controllers;

class Welcome extends BaseController {
	
	use ResponseTrait;

	private $userModel;

	public function index(){
		return $this->view('welcome');
	}

	public function view($page, $data = [])
	{
		if (! is_file(APPPATH . 'Views/' . $page . '.php')) {
			// Whoops, we don't have a page for that!
			throw new \CodeIgniter\Exceptions\PageNotFoundException($page);
		}

		$data['title'] = "Welcome";
		echo view($page, $data);
	}
	

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
