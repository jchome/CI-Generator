<?php

use Config\Mimes;

use function PHPUnit\Framework\throwException;

/**
 * reduce the size of the image
 */
function resizeImage($imgSrc, $finalWidth, $imgDest){
    list($width, $height, $imageType) = getimagesize($imgSrc);

    if($width <= $finalWidth){
        // The file does not need any size reduction
        copy($imgSrc, $imgDest);
        return;
    }
    $ratio = $width / $height;
    $newHeight = intval($finalWidth/$ratio);

    //log_message('debug','[image_helper.php] resizeImage(): newHeight: ' . $newHeight);
    //log_message('debug','[image_helper.php] resizeImage(): imageType: ' . $imageType);

    if($imageType == IMAGETYPE_JPEG){
        $src = imagecreatefromjpeg($imgSrc);
    }elseif( $imageType == IMAGETYPE_GIF ) {
        $src = imagecreatefromgif($imgSrc);
    } elseif( $imageType == IMAGETYPE_PNG ) {
        $src = imagecreatefrompng($imgSrc);
    }else{
        throwException(new Exception("Image type is unknown."));
    }
    //log_message('debug','[image_helper.php] resizeImage(): image loaded.');

    $dst = imagecreatetruecolor($finalWidth, $newHeight);
    
    // Keep transparency
    if( $imageType == IMAGETYPE_PNG || $imageType == IMAGETYPE_GIF){
        $background = imagecolorallocate($dst , 0, 0, 0);
        // Removing the black from the placeholder
        imagecolortransparent($dst, $background);

        // Turning off alpha blending (to ensure alpha channel information
        // is preserved, rather than removed (blending with the rest of the
        // image in the form of black))
        imagealphablending($dst, false);

        // Turning on alpha channel information saving (to ensure the full range
        // of transparency is preserved)
        imagesavealpha($dst, true);
    }
    
    $result = imagecopyresampled($dst, $src, 0, 0, 0, 0, $finalWidth, $newHeight, $width, $height);
    if(! $result){
        //log_message('debug','[image_helper.php] resizeImage(): imagecopyresampled failed.');
        return false;
    }
    //log_message('debug','[image_helper.php] resizeImage(): imagecopyresampled done.');

    if($imageType == IMAGETYPE_JPEG){
        imagejpeg($dst, $imgDest);
    }elseif( $imageType == IMAGETYPE_GIF ) {
        imagegif($dst, $imgDest);
    } elseif( $imageType == IMAGETYPE_PNG ) {
        imagepng($dst, $imgDest);
    }
    //log_message('debug','[image_helper.php] resizeImage(): dest image saved as ' . $imgDest);

    return true;
}

/**
 * 'inputData' like 'data:image/png;base64,iVBORw0KG...' 
 */
function extractMetadata($inputData){
    if($inputData == "" || !str_starts_with($inputData, "data:")){
        return ["mime" => "", "data" => ""];
    }

    list($type, $rawData) = explode(',', substr($inputData, 5) );
    list($mime, $encoding) = explode(';', $type);
    
    if($encoding != "base64"){
        throwException(new Exception("Unknown encoding " . $encoding));
    }
    $data = base64_decode($rawData);
    return [
        "mime" => $mime, 
        "data" => $data
    ];
}

function manageFileUpload($data, $fieldName, $existingObject = null){    //log_message('debug', "fieldName = " . $fieldName);
    if($existingObject[$fieldName] == "" && $data[$fieldName] == ""){
        // Before: no file --> After: no file
        // ==> Nothing to do
        log_message('debug', "Nothing to do");
        return $data;
    }
    if($data[$fieldName] == "DELETE"){
        // Before: a file --> After: no file
        if($existingObject != null && $existingObject[$fieldName] != ""){
            try{
                // Delete the file on disk
                unlink(PUBLIC_PATH . 'uploads/' . $existingObject[$fieldName]);
            }catch(Exception $e){
                log_message('debug', 'file not found: '. PUBLIC_PATH . 'uploads/' . $existingObject[$fieldName]);
            }
            $data[$fieldName] = "";
        }
        return $data;
    }
    if(str_starts_with($data[$fieldName], "data:")){
        if($existingObject[$fieldName] != ""){
            // Before: a file ==> Remove this file, there is a new one
            try{
                // Delete the file on disk
                unlink(PUBLIC_PATH . 'uploads/' . $existingObject[$fieldName]);
            }catch(Exception $e){
                log_message('debug', 'file not found: '. PUBLIC_PATH . 'uploads/' . $existingObject[$fieldName]);
            }
        } 
        // Before: no file --> After: a new file to upload
        // ==> Get the new file
        log_message('debug', "Getting the new file");
        $metadata = extractMetadata($data[$fieldName]);
        // Save file with the good extension
        $preview_ext = Mimes::guessExtensionFromType($metadata["mime"]);
        $filename =  'content_' . $data['id'] . '_'.$fieldName.'-'.time().'.' . $preview_ext;
        file_put_contents(PUBLIC_PATH . 'uploads/' . $filename, $metadata["data"]);
        $data[$fieldName] = $filename;
        return $data;
    }
    log_message('debug', "Case not managed in image_helper...");
    log_message('debug', "*****************************");
    log_message('debug', "data = " . print_r($data, true));
    log_message('debug', "existingObject = " . print_r($existingObject, true));

    return $data;
}

?>