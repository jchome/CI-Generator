<html>
    <body>
        <p>
            Ce message a été envoyé car vous avez demandé un changement de mot de passe. 
            Si vous n'êtes pas à l'origine de cette demande, il suffit d'ignorer ce message.
        </p>
            
        <p>Pour choisir un nouveau mot de passe, veuillez cliquer sur le lien ci-dessous: <br>
            <a href="<?= $link ?>"><?= $link ?></a>
        </p>
        <p>
            Vous disposez de 10 minutes pour changer votre mot de passe. 
            Passé ce délai, cette demande sera expirée.
        </p>
            
    </body>
</html>