<!doctype html>
<html>

<head>
    <title>Welcome</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />

<style>
html,body {
  height: 100%
}
</style>
</head>

<body>
<div class="h-100 d-flex align-items-center justify-content-center">
  <div>
    <h1>Welcome</h1>
  </div>
</div>
    

</body>

</html>