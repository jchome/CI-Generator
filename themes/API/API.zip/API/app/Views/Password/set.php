<!doctype html>
<html lang="fr">
<head>
    <title>Changement de mot de passe 2/3</title>

    <meta
      name="viewport"
      content="viewport-fit=cover, width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"
    />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link rel="shortcut icon" type="image/png" href="<?= base_url() ?>/favicon.png"/>

    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />

    <!-- Bootstrap icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="<?= base_url() ?>/assets/css/password.css" />
</head>
<body>

<?php
$fields_info = array('passwordToken' => $passwordToken);
echo form_open_multipart(base_url('/Password/apply'), 'class="form-horizontal"', $fields_info);
?>

<div class="container my-lg-5">
    <div class="p-5 text-center bg-body-tertiary rounded-3 card">
        <i class="bi bi-shield-exclamation" style="font-size: 64px"></i>
        <h1 class="text-body-emphasis">Changement de mot de passe</h1>
        <p class="col-12 col-lg-8 mx-auto fs-5 text-muted">
            Etape 2 sur 3
        </p>
        <div class="col-8 mx-auto fs-5">
            <div class="progress-line-wrapper">
                <div class="progress-line">
                    <div class="progress-content step-1"></div>
                    <div class="part done item-1"><i class="bi bi-fingerprint"></i></div>
                    <div class="part current item-2"><i class="bi bi-key"></i></div>
                    <div class="part item-3"><i class="bi bi-shield-check"></i></div>
                </div>
            </div>
        </div>

<?php
if(isset($error)){
	echo '<div class="callout-error">' . $error . '</div>';
}
?>

        <div class="row mb-3">
            <label for="password" class="text-start">
                Votre nouveau mot de passe
            </label>
            <div class="d-flex position-relative">
                <input class="form-control" type="password" name="password" 
                    id="password" value="" onkeyup="onPasswordUpdated(event)" onclick="showPasswordToggle(event)">
                <button type="button" class="d-none toggle-password" onclick="togglePassword(event)"
                    title="Afficher le mot de passe">
                </button>
            </div>
            <div class="complexity-result">
                <div class="check failed" id="lowercase">Contient au moins une minuscule</div>
                <div class="check failed" id="uppercase">Contient au moins une MAJUSCULE</div>
                <div class="check failed" id="number">Contient au moins un chiffre</div>
                <div class="check failed" id="special">Contient au moins un caractère spécial</div>
                <div class="check failed" id="length">Est composé d'au moins 6 caractères</div>
            </div>
        </div>
        <div class="row mb-3">
            <label for="password" class="text-start">
                Saissez encore votre nouveau mot de passe
            </label>
            <div class="d-flex position-relative">
                <input class="form-control" type="password" name="password2" 
                    id="password2" value="" onkeyup="onPasswordUpdated(event)" onclick="showPasswordToggle(event)">
                <button type="button" class="d-none toggle-password" onclick="togglePassword(event)"
                    title="Afficher le mot de passe">
                </button>
            </div>
            <div class="complexity-result">
                <div class="check failed" id="identical">Est le même que le mot de passe ci-dessus</div>
            </div>
        </div>

        <div class="d-flex justify-content-center mt-5">
            <button type="submit" class="btn btn-primary"><?= lang('App.form.button.apply') ?></button>
        </div>

    </div>
</div> <!-- .container -->


<?php
echo form_close('');
?>
<script>
function onPasswordUpdated(event){
    const passwordElt = document.querySelector('input#password')
    const password2Elt = document.querySelector('input#password2')
    
    const containsLower = /[a-z]/.test( passwordElt.value )
    const containsUpper = /[A-Z]/.test( passwordElt.value )
    const containsNumeric = /[0-9]/.test( passwordElt.value )
    const containsSpecial = /[\'\-\!\"\#\$\%\&\(\)\*\,\.\/\:\;\?\@\[\]\^\_\{\|\}\~\+\<\=\>\§ù\£]/.test( passwordElt.value )
    const samePasswd = passwordElt.value == password2Elt.value

    document.querySelector('button[type="submit"]').disabled = true
    var allowSubmit = true
    if(containsLower){
        document.getElementById("lowercase").classList.remove('failed')
        document.getElementById("lowercase").classList.add('success')
    }else{
        document.getElementById("lowercase").classList.remove('success')
        document.getElementById("lowercase").classList.add('failed')
        allowSubmit = false
    }
    if(containsUpper){
        document.getElementById("uppercase").classList.remove('failed')
        document.getElementById("uppercase").classList.add('success')
    }else{
        document.getElementById("uppercase").classList.remove('success')
        document.getElementById("uppercase").classList.add('failed')
        allowSubmit = false
    }
    if(containsNumeric){
        document.getElementById("number").classList.remove('failed')
        document.getElementById("number").classList.add('success')
    }else{
        document.getElementById("number").classList.remove('success')
        document.getElementById("number").classList.add('failed')
        allowSubmit = false
    }
    if(containsSpecial){
        document.getElementById("special").classList.remove('failed')
        document.getElementById("special").classList.add('success')
    }else{
        document.getElementById("special").classList.remove('success')
        document.getElementById("special").classList.add('failed')
        allowSubmit = false
    }
    if(passwordElt.value.length >= 6){
        document.getElementById("length").classList.remove('failed')
        document.getElementById("length").classList.add('success')
    }else{
        document.getElementById("length").classList.remove('success')
        document.getElementById("length").classList.add('failed')
        allowSubmit = false
    }
    if(samePasswd){
        document.getElementById("identical").classList.remove('failed')
        document.getElementById("identical").classList.add('success')
    }else{
        document.getElementById("identical").classList.remove('success')
        document.getElementById("identical").classList.add('failed')
        allowSubmit = false
    }

    if(allowSubmit){
        document.querySelector('button[type="submit"]').disabled = false
    }
}

function showPasswordToggle(event){
    const togglePswdElt = event.target.parentElement.querySelector('button')
    togglePswdElt.classList.remove("d-none")
}

function togglePassword(event){
    const passwordElt = event.target.parentElement.querySelector('input')
    const togglerElt = event.target.parentElement.querySelector('.toggle-password')
    
    if(passwordElt.type === "password"){
        passwordElt.type = "text"
        togglerElt.classList.add("active")
        togglerElt.classList.remove("inactive")
    }else{
        passwordElt.type = "password"
        togglerElt.classList.add("inactive")
        togglerElt.classList.remove("active")
    }
}
</script>

</body>
</html>